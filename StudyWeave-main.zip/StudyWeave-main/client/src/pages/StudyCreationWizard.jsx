import React, { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "../api/axios";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { StudyCreationSuccessDialog } from "./StudyCreationSuccessDialog";

const WIZARD_STEPS = [
  { id: 0, label: "Study details", helper: "Title, description, window" },
  { id: 1, label: "Artifacts", helper: "Pick or upload artifacts" },
  { id: 2, label: "Competency gate", helper: "Choose quiz + targeting" },
  { id: 3, label: "Launch", helper: "Review and launch" },
];

const DEFAULT_CRITERIA = [];

const ASSESSMENTS = [
  { id: "asm-1", title: "Baseline Competency Check", completions: 12 },
  { id: "asm-2", title: "Mobile UX Diagnostic", completions: 5 },
];

const PARTICIPANT_SEGMENTS = [
  { id: "seg-1", label: "Senior Engineers • 5+ yrs" },
  { id: "seg-2", label: "Bootcamp graduates" },
  { id: "seg-3", label: "Design partners" },
];

const ARTIFACT_MODE_OPTIONS = [
  { value: "stage1", label: "Stage 1 – Participant bug labeling" },
  { value: "solid", label: "SOLID violations" },
  { value: "clone", label: "Patch clone detection" },
  { value: "snapshot", label: "Snapshot change vs failure" },
  { value: "custom", label: "Custom stage" },
];

const CUSTOM_QUESTION_TYPES = [
  { value: "mcq", label: "Multiple choice (single select)" },
  { value: "dropdown", label: "Dropdown (single select)" },
  { value: "answer", label: "Open answer" },
];

function StudyCreationWizard() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);
  const [user, setUser] = useState(null);
  const [title, setTitle] = useState("Comparison Study — Q4 drop");
  const [description, setDescription] = useState(
    "Participants compare human and AI generated artifacts and rate readiness.",
  );
  const [isPublic, setIsPublic] = useState(false);
  const [isBlinded, setIsBlinded] = useState(false);
  const [allowReviewers, setAllowReviewers] = useState(false);
  const [criteria, setCriteria] = useState(DEFAULT_CRITERIA);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newCriterionText, setNewCriterionText] = useState("");
  const [newCriterionWeight, setNewCriterionWeight] = useState("10");
  const [editingCriterionIndex, setEditingCriterionIndex] = useState(null);
  const [participantTarget, setParticipantTarget] = useState("20");
  const [studyMode, setStudyMode] = useState(ARTIFACT_MODE_OPTIONS[0].value);
  const [windowStart, setWindowStart] = useState("");
  const [windowEnd, setWindowEnd] = useState("");
  const [selectedArtifacts, setSelectedArtifacts] = useState([]);
  const [customQuestions, setCustomQuestions] = useState([]);
  const [questionPrompt, setQuestionPrompt] = useState("");
  const [questionType, setQuestionType] = useState("mcq");
  const [questionOptions, setQuestionOptions] = useState(["", ""]);
  const [snapshotArtifacts, setSnapshotArtifacts] = useState({
    reference: "",
    failure: "",
    diff: "",
  });
  const lastNonSnapshotArtifactsRef = useRef([]);
  const wasSnapshotModeRef = useRef(false);
  const [requireAssessment, setRequireAssessment] = useState(true);
  const [selectedAssessment, setSelectedAssessment] = useState("asm-1");
  const [selectedSegment, setSelectedSegment] = useState("seg-1");
  const [autoInvite, setAutoInvite] = useState(true);
  const [notes, setNotes] = useState("");
  const [error, setError] = useState(null);
  const [participantSearch, setParticipantSearch] = useState("");
  const [participants, setParticipants] = useState([]);
  const [participantsError, setParticipantsError] = useState("");
  const [isParticipantsLoading, setIsParticipantsLoading] = useState(false);
  const [selectedParticipants, setSelectedParticipants] = useState([]);
  const [recentlyAssignedParticipants, setRecentlyAssignedParticipants] = useState([]);
  const [isSuccessDialogOpen, setIsSuccessDialogOpen] = useState(false);
  const [newlyCreatedStudy, setNewlyCreatedStudy] = useState(null);
  const [expandedParticipants, setExpandedParticipants] = useState([]);
  const [artifacts, setArtifacts] = useState([]);
  const [artifactsError, setArtifactsError] = useState("");
  const [isArtifactsLoading, setIsArtifactsLoading] = useState(false);
  const getTotalWeight = () => criteria.reduce((sum, c) => sum + Number(c.weight), 0);
  const totalCriteriaWeight = useMemo(() => getTotalWeight(), [criteria]);

  useEffect(() => {
    const raw = localStorage.getItem("user");
    if (!raw) {
      navigate("/login");
      return;
    }
    try {
      const parsed = JSON.parse(raw);
      if (parsed.role !== "researcher") {
        navigate("/login");
        return;
      }
      setUser(parsed);
    } catch {
      navigate("/login");
    }
  }, [navigate]);

  const artifactOwnerId = useMemo(() => {
    if (user?.id) return user.id;
    if (user?.userId) return user.userId;
    return null;
  }, [user?.id]);

  useEffect(() => {
    if (!artifactOwnerId) {
      return;
    }

    const fetchArtifacts = async () => {
      setIsArtifactsLoading(true);
      setArtifactsError("");
      try {
        const { data } = await axios.get(`/api/artifacts/user/${artifactOwnerId}`);
        setArtifacts(data.artifacts || []);
      } catch (error) {
        const status = error.response?.status;
        if (status === 404) {
          setArtifacts([]);
          return;
        }
        console.error("Failed to load artifacts", error);
        const message = error.response?.data?.message || "Unable to load artifacts";
        setArtifactsError(message);
      } finally {
        setIsArtifactsLoading(false);
      }
    };
    fetchArtifacts();
  }, [artifactOwnerId]);

  useEffect(() => {
    if (!user?.id) {
      return;
    }

    const fetchParticipants = async () => {
      setIsParticipantsLoading(true);
      setParticipantsError("");
      try {
        const { data } = await axios.get("/api/competency/participants/overview", {
          params: { researcherId: user.id },
        });
        setParticipants(data.participants || []);
      } catch (error) {
        console.error("Failed to load competency participants", error);
        setParticipantsError(error.response?.data?.message || "Unable to load competency participants");
      } finally {
        setIsParticipantsLoading(false);
      }
    };

    fetchParticipants();
  }, [user]);

  useEffect(() => {
    if (!isPublic) {
      return;
    }
    setSelectedParticipants([]);
    setAutoInvite(false);
  }, [isPublic]);

  useEffect(() => {
    if (studyMode === "snapshot") {
      if (!wasSnapshotModeRef.current) {
        wasSnapshotModeRef.current = true;
        lastNonSnapshotArtifactsRef.current = selectedArtifacts;
      }
    } else if (wasSnapshotModeRef.current) {
      wasSnapshotModeRef.current = false;
      if (lastNonSnapshotArtifactsRef.current.length) {
        setSelectedArtifacts(lastNonSnapshotArtifactsRef.current);
        lastNonSnapshotArtifactsRef.current = [];
      }
      setSnapshotArtifacts({ reference: "", failure: "", diff: "" });
    }
  }, [studyMode, selectedArtifacts]);

  useEffect(() => {
    if (studyMode !== "snapshot") {
      return;
    }
    const picks = Object.values(snapshotArtifacts)
      .map((value) => Number(value))
      .filter((value) => Number.isFinite(value));
    const unique = Array.from(new Set(picks));
    setSelectedArtifacts(unique);
  }, [studyMode, snapshotArtifacts]);

  const progressPercent = useMemo(() => {
    const progress = ((currentStep + 1) / WIZARD_STEPS.length) * 100;
    return Math.min(100, Math.max(0, Math.round(progress)));
  }, [currentStep]);

  const launchSummary = useMemo(() => {
    return {
      artifacts: selectedArtifacts.length,
      criteria: criteria.length,
      participants: selectedParticipants.length || participantTarget,
      schedule: windowStart && windowEnd ? `${windowStart} → ${windowEnd}` : "TBD",
      competencyGate: requireAssessment ? "Required" : "Optional",
    };
  }, [
    selectedArtifacts.length,
    criteria.length,
    selectedParticipants.length,
    participantTarget,
    windowStart,
    windowEnd,
    requireAssessment,
  ]);

  const assignedParticipantSummary = useMemo(() => {
    if (!recentlyAssignedParticipants.length) {
      return "";
    }
    const names = recentlyAssignedParticipants.map((participant) => {
      if (participant.name?.trim()) {
        return participant.name.trim();
      }
      if (participant.email?.trim()) {
        return participant.email.trim();
      }
      return participant.id;
    });
    if (names.length === 1) {
      return names[0];
    }
    if (names.length === 2) {
      return `${names[0]} and ${names[1]}`;
    }
    if (names.length === 3) {
      return `${names[0]}, ${names[1]}, and ${names[2]}`;
    }
    const remaining = names.length - 2;
    return `${names[0]}, ${names[1]} and ${remaining} more`;
  }, [recentlyAssignedParticipants]);

  const toggleArtifact = (artifactId) => {
    if (studyMode === "snapshot") {
      return;
    }
    setError(null);
    setSelectedArtifacts((prev) => {
      const exists = prev.includes(artifactId);
      if (exists) {
        return prev.filter((id) => id !== artifactId);
      }
      const next = [...prev, artifactId];
      if (studyMode === "custom" && next.length > 5) {
        setError("Custom stage supports a maximum of 5 artifacts.");
        return prev;
      }
      return next;
    });
  };

  const resetCriterionDialog = () => {
    setNewCriterionText("");
    setNewCriterionWeight("10");
    setEditingCriterionIndex(null);
  };

  const resetQuestionDraft = () => {
    setQuestionPrompt("");
    setQuestionType("mcq");
    setQuestionOptions(["", ""]);
  };

  const handleAddCustomQuestion = () => {
    const prompt = questionPrompt.trim();
    if (!prompt) {
      setError("Enter a prompt for your custom question.");
      return;
    }
    let options = [];
    if (questionType === "mcq" || questionType === "dropdown") {
      options = questionOptions.map((opt) => opt.trim()).filter(Boolean);
      if (options.length < 2) {
        setError("Add at least two options for multiple choice or dropdown questions.");
        return;
      }
    }
    const id = `custom-q-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setCustomQuestions((prev) => [...prev, { id, prompt, type: questionType, options }]);
    setError(null);
    resetQuestionDraft();
  };

  const handleRemoveCustomQuestion = (id) => {
    setCustomQuestions((prev) => prev.filter((q) => q.id !== id));
  };

  const updateQuestionOption = (index, value) => {
    setQuestionOptions((prev) =>
      prev.map((opt, idx) => (idx === index ? value : opt)),
    );
  };

  const addQuestionOption = () => {
    setQuestionOptions((prev) => [...prev, ""]);
  };

  const removeQuestionOption = (index) => {
    setQuestionOptions((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleSaveCriterion = () => {
    if (!newCriterionText.trim()) return;
    const weightNumber = Number(newCriterionWeight) || 10;

    setCriteria((prev) => {
      if (editingCriterionIndex === null || editingCriterionIndex < 0 || editingCriterionIndex >= prev.length) {
        return [...prev, { label: newCriterionText.trim(), weight: weightNumber }];
      }

      const updated = [...prev];
      updated[editingCriterionIndex] = { label: newCriterionText.trim(), weight: weightNumber };
      return updated;
    });

    resetCriterionDialog();
    setIsDialogOpen(false);
  };

  const handleEditCriterion = (index) => {
    const item = criteria[index];
    if (!item) return;
    setNewCriterionText(item.label);
    setNewCriterionWeight(String(item.weight));
    setEditingCriterionIndex(index);
    setIsDialogOpen(true);
  };

  const handleRemoveCriterion = (index) => {
    setCriteria((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSnapshotSelect = (role, value) => {
    setSnapshotArtifacts((prev) => ({
      ...prev,
      [role]: value,
    }));
  };

  const handleCreateStudy = async () => {
    setError(null);
    if (!user?.id) {
      setError("Please sign in as a researcher to create a study.");
      return;
    }
    const sanitizedCustomQuestions = sanitizeCustomQuestionsForPayload();
    if (studyMode === "custom") {
      if (!sanitizedCustomQuestions.length) {
        setError("Add at least one custom question (MCQ, dropdown, or open answer).");
        return;
      }
      if (selectedArtifacts.length === 0) {
        setError("Select at least one artifact for the custom stage.");
        return;
      }
      if (selectedArtifacts.length > 5) {
        setError("Custom stage supports up to 5 artifacts.");
        return;
      }
    }
    if (studyMode === "snapshot" && !validateSnapshotArtifacts()) {
      return;
    }
    const snapshotMeta =
      studyMode === "snapshot"
        ? {
            reference: snapshotArtifacts.reference ? Number(snapshotArtifacts.reference) : null,
            failure: snapshotArtifacts.failure ? Number(snapshotArtifacts.failure) : null,
            diff: snapshotArtifacts.diff ? Number(snapshotArtifacts.diff) : null,
          }
        : null;
    const customArtifactIds =
      studyMode === "custom"
        ? Array.from(new Set(selectedArtifacts)).slice(0, 5)
        : [];
    const selectedArtifactIds = Array.from(new Set(selectedArtifacts));
    const participantIdsForPayload = isPublic ? [] : selectedParticipants;
    const autoInviteFlag = isPublic ? false : autoInvite;

    const payload = {
      title,
      description,
      criteria,
      researcherId: user.id,
      isPublic,
      isBlinded,
      allowReviewers,
      timelineStart: windowStart || null,
      timelineEnd: windowEnd || null,
      defaultArtifactMode: studyMode,
      autoInvite: autoInviteFlag,
      selectedParticipants: participantIdsForPayload,
      metadata: {
        participantTarget: Number(participantTarget) || 0,
        windowStart,
        windowEnd,
        notes,
        requireAssessment,
        selectedAssessment: requireAssessment ? selectedAssessment : null,
        selectedSegment: requireAssessment ? selectedSegment : null,
        autoInvite: autoInviteFlag,
        selectedArtifacts: selectedArtifactIds,
        selectedParticipants: participantIdsForPayload,
        isPublic,
        isBlinded,
        defaultArtifactMode: studyMode,
        ...(snapshotMeta ? { snapshotArtifacts: snapshotMeta } : {}),
        ...(studyMode === "custom"
          ? {
              customQuestions: sanitizedCustomQuestions,
              customArtifactIds,
            }
          : {}),
      },
      ...(studyMode === "custom" ? { customQuestions: sanitizedCustomQuestions } : {}),
    };

    try {
      const response = await axios.post("/api/studies", payload);
      const newStudy = response.data?.study;
      setNewlyCreatedStudy(newStudy);
      setIsSuccessDialogOpen(true);
    } catch (err) {
      console.error("Failed to create study:", err);
      setError(err.response?.data?.message || "Failed to create study. Please try again.");
    }
  };

  const participantSelectionDisabled = isPublic;

  const filteredParticipants = useMemo(() => {
    const list = Array.isArray(participants) ? participants : [];
    if (!participantSearch.trim()) {
      return list;
    }
    const term = participantSearch.toLowerCase();
    return list.filter((participant) => {
      const name = participant.name?.toLowerCase() || "";
      const email = participant.email?.toLowerCase() || "";
      const assignments = Array.isArray(participant.assignments) ? participant.assignments : [];
      const matchesAssignment = assignments.some((assignment) =>
        (assignment.assessmentTitle || "").toLowerCase().includes(term),
      );
      return name.includes(term) || email.includes(term) || matchesAssignment;
    });
  }, [participantSearch, participants]);

  const toggleParticipant = (participantId) => {
    if (isPublic) {
      return;
    }
    setSelectedParticipants((prev) =>
      prev.includes(participantId)
        ? prev.filter((id) => id !== participantId)
        : [...prev, participantId],
    );
  };

  const selectAllParticipants = () => {
    if (isPublic) {
      return;
    }
    const everyId = participants.map((participant) => participant.id);
    setSelectedParticipants(everyId);
  };

  const toggleParticipantDetails = (participantId) => {
    setExpandedParticipants((prev) =>
      prev.includes(participantId)
        ? prev.filter((id) => id !== participantId)
        : [...prev, participantId],
    );
  };

  const humanize = (value) => {
    if (!value) return "Unknown";
    return value
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  const sanitizeCustomQuestionsForPayload = () => {
    return customQuestions
      .map((q, idx) => {
        const prompt = (q.prompt || "").trim();
        const type = q.type;
        if (!prompt || !["mcq", "dropdown", "answer"].includes(type)) {
          return null;
        }
        const id = q.id || `custom-q-${idx + 1}`;
        let options = [];
        if (type === "mcq" || type === "dropdown") {
          options = Array.isArray(q.options)
            ? q.options.map((opt) => (opt || "").trim()).filter(Boolean)
            : [];
          if (options.length < 2) {
            return null;
          }
        }
        return { id, prompt, type, options };
      })
      .filter(Boolean);
  };

  const decisionLabel = (decision) => {
    if (!decision || decision === "undecided") {
      return "Awaiting decision";
    }
    return humanize(decision);
  };

  const statusToneClass = (status) => {
    const normalized = (status || "").toLowerCase();
    if (normalized === "reviewed") return "bg-emerald-600 text-white";
    if (normalized === "submitted") return "bg-blue-600 text-white";
    if (normalized === "in_progress") return "bg-amber-500 text-white";
    if (normalized === "pending") return "bg-muted text-foreground";
    return "bg-muted text-foreground";
  };

  const decisionToneClass = (decision) => {
    const normalized = (decision || "").toLowerCase();
    if (normalized === "approved") return "bg-green-600 text-white";
    if (normalized === "rejected") return "bg-destructive text-destructive-foreground";
    return "bg-muted text-foreground";
  };

  const formatDateTime = (value, fallback = "N/A") => {
    if (!value) return fallback;
    return new Date(value).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const normalizeDateOnly = (value) => {
    if (!value) return null;
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime())) {
      return null;
    }
    parsed.setHours(0, 0, 0, 0);
    return parsed;
  };

  const validateWindowBeforeNext = () => {
    const start = normalizeDateOnly(windowStart);
    const end = normalizeDateOnly(windowEnd);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (!start || !end) {
      setError("Both window start and window end are required.");
      return false;
    }

    if (start && start < today) {
      setError("Window start cannot be before today's date.");
      return false;
    }

    if (start && end && end < start) {
      setError("Window end cannot be before the start date.");
      return false;
    }

    return true;
  };

  const validateSnapshotArtifacts = () => {
    if (studyMode !== "snapshot") {
      return true;
    }
    const { reference, failure, diff } = snapshotArtifacts;
    if (!reference || !failure || !diff) {
      setError("Select reference, failure, and diff artifacts for this snapshot study.");
      return false;
    }
    const unique = new Set([reference, failure, diff]);
    if (unique.size !== 3) {
      setError("Reference, failure, and diff artifacts must be different.");
      return false;
    }
    return true;
  };

  const validateCriteriaBeforeNext = () => {
    if (criteria.length === 0) {
      setError("You must create at least one evaluation criterion before continuing.");
      return false;
    }
    const total = getTotalWeight();
    if (total !== 100) {
      setError(`Total weight must be exactly 100%. Current total: ${total}%.`);
      return false;
    }
    return true;
  };

  const goBack = () => {
    setError(null);
    if (currentStep === 3) {
      setRecentlyAssignedParticipants([]);
    }
    setCurrentStep((prev) => Math.max(0, prev - 1));
  };
  const goNext = () => {
    setError(null);
    if (currentStep === 0) {
      if (!validateWindowBeforeNext()) return;
    }
    if (currentStep === 1) {
      if (!validateCriteriaBeforeNext()) return;
      if (!validateSnapshotArtifacts()) return;
    }
    if (currentStep === 2) {
      if (selectedParticipants.length) {
        const snapshot = selectedParticipants.map((participantId) => {
          const participant = participants.find((p) => p.id === participantId);
          return {
            id: participantId,
            name: participant?.name || "",
            email: participant?.email || "",
          };
        });
        setRecentlyAssignedParticipants(snapshot);
      } else {
        setRecentlyAssignedParticipants([]);
      }
    }
    setCurrentStep((prev) => Math.min(WIZARD_STEPS.length - 1, prev + 1));
  };

  const primaryAction = currentStep === WIZARD_STEPS.length - 1 ? handleCreateStudy : goNext;
  const primaryLabel = currentStep === WIZARD_STEPS.length - 1 ? "Launch study" : "Continue";

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-8 p-6 md:p-10">
      <div className="grid gap-6 lg:grid-cols-[2fr,1fr]">
        <Card>
          <CardHeader className="space-y-2">
            <CardTitle>Study creation wizard</CardTitle>
            <CardDescription>Design the study, gate participants, and schedule launch.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <div className="flex items-center justify-between text-sm text-muted-foreground">
                <span>
                  Step {currentStep + 1} of {WIZARD_STEPS.length}
                </span>
                <span>{progressPercent}% complete</span>
              </div>
              <Progress className="mt-2" value={progressPercent} />
            </div>
            <div className="space-y-4">
              {WIZARD_STEPS.map((step, index) => (
                <div
                  key={step.id}
                  className={`rounded-md border p-3 ${index === currentStep ? "border-primary bg-primary/5" : "border-muted"}`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">{step.label}</p>
                      <p className="text-xs text-muted-foreground">{step.helper}</p>
                    </div>
                    {index < currentStep ? <Badge variant="outline">Done</Badge> : null}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Launch readiness</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-sm text-muted-foreground">
            <div className="rounded-md border p-3">
              <p className="text-xs uppercase">Artifacts</p>
              <p className="text-base font-medium text-foreground">{launchSummary.artifacts} selected</p>
            </div>
            <div className="rounded-md border p-3">
              <p className="text-xs uppercase">Participant target</p>
              <p className="text-base font-medium text-foreground">{launchSummary.participants} seats</p>
            </div>
            <div className="rounded-md border p-3">
              <p className="text-xs uppercase">Window</p>
              <p className="text-base font-medium text-foreground">{launchSummary.schedule}</p>
            </div>
            <div className="rounded-md border p-3">
              <p className="text-xs uppercase">Competency gate</p>
              <p className="text-base font-medium text-foreground">{launchSummary.competencyGate}</p>
            </div>
            <div className="rounded-md border p-3">
              <p className="text-xs uppercase">Reviewer access</p>
              <p className="text-base font-medium text-foreground">
                {allowReviewers ? "Enabled" : "Disabled"}
              </p>
            </div>
            <Separator />
            <p>Need help configuring? Email researchers@studyweave.ai</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{WIZARD_STEPS[currentStep].label}</CardTitle>
          <CardDescription>{WIZARD_STEPS[currentStep].helper}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-8">
          {currentStep === 0 ? (
            <>
              <div className="space-y-2">
                <Label htmlFor="study-title">Study title</Label>
                <Input
                  id="study-title"
                  placeholder="AI vs. Human Code Readability"
                  value={title}
                  onChange={(event) => setTitle(event.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description for participants</Label>
                <Textarea
                  id="description"
                  placeholder="Participants will compare two artifacts..."
                  value={description}
                  onChange={(event) => setDescription(event.target.value)}
                />
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="window-start">Window start</Label>
                  <Input
                    id="window-start"
                    type="date"
                    value={windowStart}
                    onChange={(event) => setWindowStart(event.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="window-end">Window end</Label>
                  <Input
                    id="window-end"
                    type="date"
                    value={windowEnd}
                    onChange={(event) => setWindowEnd(event.target.value)}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="participant-target">Participant target</Label>
                <Input
                  id="participant-target"
                  type="number"
                  min="1"
                  placeholder="20"
                  value={participantTarget}
                  onChange={(event) => setParticipantTarget(event.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="study-mode">Default artifact task</Label>
                <Select value={studyMode} onValueChange={setStudyMode}>
                  <SelectTrigger id="study-mode">
                    <SelectValue placeholder="Select task" />
                  </SelectTrigger>
                  <SelectContent>
                    {ARTIFACT_MODE_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  Participants will see this assignment on their dashboard as soon as they are invited.
                </p>
              </div>
              {studyMode === "custom" && (
                <div className="space-y-4 rounded-md border border-border bg-card p-4 shadow-sm">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-foreground">Custom stage questions</p>
                      <p className="text-xs text-muted-foreground">
                        Add single-select multiple choice, dropdown, or open-answer prompts. At least one question is required.
                      </p>
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      Custom
                    </Badge>
                  </div>
                  <div className="space-y-3">
                    <div className="space-y-2">
                      <Label htmlFor="custom-question">
                        Question prompt
                      </Label>
                      <Input
                        id="custom-question"
                        placeholder="e.g., Which API is more readable?"
                        value={questionPrompt}
                        onChange={(e) => setQuestionPrompt(e.target.value)}
                      />
                    </div>
                    <div className="grid gap-3 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label>Question type</Label>
                        <Select value={questionType} onValueChange={setQuestionType}>
                          <SelectTrigger>
                            <SelectValue placeholder="Choose type" />
                          </SelectTrigger>
                          <SelectContent>
                            {CUSTOM_QUESTION_TYPES.map((type) => (
                              <SelectItem key={type.value} value={type.value}>
                                {type.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      {(questionType === "mcq" || questionType === "dropdown") && (
                        <div className="space-y-2">
                          <Label>Options (min 2)</Label>
                          <div className="space-y-2">
                            {questionOptions.map((opt, idx) => (
                              <div className="flex items-center gap-2" key={`opt-${idx}`}>
                                <Input
                                  value={opt}
                                  placeholder={`Option ${idx + 1}`}
                                  onChange={(e) => updateQuestionOption(idx, e.target.value)}
                                />
                                {questionOptions.length > 2 && (
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => removeQuestionOption(idx)}
                                    title="Remove option"
                                  >
                                    x
                                  </Button>
                                )}
                              </div>
                            ))}
                          </div>
                          <Button variant="outline" size="sm" onClick={addQuestionOption}>
                            Add option
                          </Button>
                        </div>
                      )}
                    </div>
                    <div className="flex items-center justify-end gap-3">
                      <Button variant="ghost" onClick={resetQuestionDraft}>
                        Reset
                      </Button>
                      <Button onClick={handleAddCustomQuestion}>Add question</Button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-semibold text-foreground">Questions ({customQuestions.length})</p>
                    {customQuestions.length === 0 ? (
                      <p className="text-xs text-muted-foreground">No questions added yet.</p>
                    ) : (
                      <div className="space-y-2">
                        {customQuestions.map((q, idx) => (
                          <div
                            key={q.id}
                            className="flex items-center justify-between rounded-md border border-border bg-muted/40 p-3 text-foreground"
                          >
                            <div>
                              <p className="text-sm font-semibold text-foreground">
                                Q{idx + 1}. {q.prompt}
                              </p>
                              <p className="text-xs text-muted-foreground capitalize">
                                {q.type}
                                {q.options?.length ? ` - ${q.options.length} options` : ""}
                              </p>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleRemoveCustomQuestion(q.id)}
                            >
                              Remove
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
              <div className="space-y-2 rounded-md border p-4">
                <div className="flex items-center space-x-2">
                  <Checkbox id="blinded" checked={isBlinded} onCheckedChange={setIsBlinded} />
                  <Label htmlFor="blinded" className="font-normal">
                    Blinded evaluation (hide artifact origin)
                  </Label>
                </div>
              </div>
              <div className="space-y-2 rounded-md border p-4">
                <div className="flex items-center space-x-2">
                  <Checkbox id="public-study" checked={isPublic} onCheckedChange={setIsPublic} />
                  <Label htmlFor="public-study" className="font-normal">
                    Make this a public study for guest participants
                  </Label>
                </div>
                <p className="text-xs text-muted-foreground pl-6">
                  Guests can discover and join from the public studies board; no invitation link is generated.
                </p>
              </div>
              <div className="space-y-2 rounded-md border p-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="allow-reviewers"
                    checked={allowReviewers}
                    onCheckedChange={setAllowReviewers}
                  />
                  <Label htmlFor="allow-reviewers" className="font-normal">
                    Allow reviewer feedback on participant evaluations
                  </Label>
                </div>
                <p className="text-xs text-muted-foreground pl-6">
                  When enabled, reviewers can view submissions for this study and leave a 1–5 rating and comment for the researcher.
                </p>
              </div>
              {error && (
                <p className="text-sm text-destructive">{error}</p>
              )}
            </>
          ) : null}

          {currentStep === 1 ? (
            <>
              <div className="space-y-2">
                <Label>Artifact selection</Label>
                <p className="text-sm text-muted-foreground">
                  {studyMode === "snapshot"
                    ? "Pick which artifacts serve as the reference, failure, and diff for this snapshot task."
                    : "Choose the artifacts for this study. You can upload more from the artifacts page."}
                </p>
                {studyMode === "custom" && (
                  <p className="text-xs text-amber-700 border border-amber-200 bg-amber-50 rounded-md px-3 py-2">
                    Custom stage requires 1–5 artifacts. Currently selected: {selectedArtifacts.length}.
                  </p>
                )}
                {artifactsError ? (
                  <div className="rounded-md border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">
                    {artifactsError}
                  </div>
                ) : null}
                {isArtifactsLoading ? (
                  <div className="rounded-md border p-3 text-sm text-muted-foreground">Loading artifacts...</div>
                ) : artifacts.length === 0 ? (
                  <div className="rounded-md border p-3 text-sm text-muted-foreground">
                    No artifacts found. Upload artifacts first from the Artifacts page.
                  </div>
                ) : studyMode === "snapshot" ? (
                  <div className="space-y-4 rounded-md border p-4">
                    <p className="text-xs text-muted-foreground">
                      Reference = intended UI, Failure = regression screenshot, Diff = researcher-provided highlight.
                    </p>
                    <div className="grid gap-4 md:grid-cols-3">
                      {[
                        { key: "reference", label: "Reference artifact" },
                        { key: "failure", label: "Failure artifact" },
                        { key: "diff", label: "Diff artifact" },
                      ].map((role) => (
                        <div key={role.key} className="space-y-2">
                          <Label className="text-xs text-muted-foreground">{role.label}</Label>
                          <Select
                            value={snapshotArtifacts[role.key]}
                            onValueChange={(value) => handleSnapshotSelect(role.key, value)}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Choose artifact" />
                            </SelectTrigger>
                            <SelectContent>
                              {artifacts.map((artifact) => {
                                const value = String(artifact.id);
                                const isTaken = Object.entries(snapshotArtifacts).some(
                                  ([otherRole, otherValue]) =>
                                    otherRole !== role.key && otherValue && otherValue === value,
                                );
                                return (
                                  <SelectItem key={artifact.id} value={value} disabled={isTaken}>
                                    {artifact.name || `Artifact ${artifact.id}`}
                                  </SelectItem>
                                );
                              })}
                            </SelectContent>
                          </Select>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {artifacts.map((artifact) => (
                      <div
                        key={artifact.id}
                        className={`flex items-center justify-between rounded-md border p-3 ${selectedArtifacts.includes(artifact.id) ? "border-primary bg-primary/5" : ""}`}
                      >
                        <div>
                          <p className="text-sm font-medium">{artifact.name || `Artifact ${artifact.id}`}</p>
                          <p className="text-xs text-muted-foreground capitalize">
                            {artifact.type || "Unknown type"}
                          </p>
                          {artifact.tags && artifact.tags.length > 0 ? (
                            <div className="mt-1 flex flex-wrap gap-1">
                              {artifact.tags.map((tag) => (
                                <Badge key={tag.id || tag.name} variant="outline" className="text-[10px]">
                                  {tag.name}
                                </Badge>
                              ))}
                            </div>
                          ) : null}
                        </div>
                        <Checkbox
                          checked={selectedArtifacts.includes(artifact.id)}
                          onCheckedChange={() => toggleArtifact(artifact.id)}
                        />
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Evaluation criteria</Label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      resetCriterionDialog();
                      setIsDialogOpen(true);
                    }}
                  >
                    Add new +
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground">
                  e.g., Readability, Correctness, Maintainability, Confidence…
                </p>
                <div className="space-y-2 rounded-md border p-4">
                  {criteria.map((item, index) => (
                    <div
                      key={`${item.label}-${index}`}
                      className="flex flex-wrap items-center justify-between gap-2 rounded-md border p-2 text-sm"
                    >
                      <div className="flex items-center gap-3">
                        <span className="font-medium">{item.label}</span>
                        <Badge variant="outline">{item.weight}%</Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditCriterion(index)}
                        >
                          Edit
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-destructive"
                          onClick={() => handleRemoveCriterion(index)}
                        >
                          Remove
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground">
                  Total weight: {totalCriteriaWeight}% (must equal 100% before launch)
                </p>

                {/* ADDED — validation error */}
                {error ? (
                  <p className="text-sm text-destructive">{error}</p>
                ) : null}
              </div>
            </>
          ) : null}

          {currentStep === 2 ? (
            <>
              <div className="space-y-4 rounded-md border p-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <Label>Select participants</Label>
                    <p className="text-xs text-muted-foreground">
                      {isParticipantsLoading
                        ? "Loading participants..."
                        : participantSelectionDisabled
                        ? "Public studies are open enrollment. Invitations are disabled."
                        : `${selectedParticipants.length} selected - showing everyone tied to your competency quizzes.`}
                    </p>
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={selectAllParticipants}
                    disabled={participantSelectionDisabled || !participants.length}
                  >
                    Select all
                  </Button>
                </div>

                {participantSelectionDisabled ? (
                  <div className="rounded-md border border-blue-200 bg-blue-50 p-3 text-xs text-blue-900">
                    Public studies disable manual invites. Participants can self-enroll from their dashboards.
                  </div>
                ) : null}

                <Input
                  placeholder="Search by name or assessment"
                  value={participantSearch}
                  onChange={(event) => setParticipantSearch(event.target.value)}
                  disabled={participantSelectionDisabled || !participants.length}
                />

                {participantsError ? <p className="text-xs text-destructive">{participantsError}</p> : null}

                <div className="max-h-[280px] space-y-2 overflow-y-auto rounded-md border p-2">
                  {isParticipantsLoading ? (
                    <p className="py-6 text-center text-xs text-muted-foreground">Fetching participants…</p>
                  ) : filteredParticipants.length ? (
                    filteredParticipants.map((participant) => {
                            const assignments = Array.isArray(participant.assignments)
                              ? participant.assignments
                              : [];
                            const hasAssignments = assignments.length > 0;
                            const isExpanded = expandedParticipants.includes(participant.id);
                            return (
                              <div
                                key={participant.id}
                                className={`flex flex-col gap-3 rounded-md border p-3 text-sm ${
                                  selectedParticipants.includes(participant.id)
                                    ? "border-primary bg-primary/5"
                                    : "border-muted"
                                }`}
                              >
                                <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
                                  <div>
                                    <p className="font-medium text-foreground">
                                      {participant.name || "Participant"}
                                      <span className="text-muted-foreground"> • {participant.email}</span>
                                    </p>
                                    <p className="text-xs text-muted-foreground">
                                      {hasAssignments
                                        ? `${assignments.length} competency ${assignments.length === 1 ? "test" : "tests"} • Last update ${formatDateTime(participant.lastActivity, "—")}`
                                        : "No competency assignments yet"}
                                    </p>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <Badge
                                      variant={participant.hasApproved ? "default" : "outline"}
                                      className={participant.hasApproved ? "bg-emerald-600 text-white" : ""}
                                    >
                                      {participant.hasApproved ? "Has approved quiz" : "Awaiting approval"}
                                    </Badge>
                                    <Button
                                      type="button"
                                      variant="ghost"
                                      size="sm"
                                      className="px-2"
                                      onClick={() => toggleParticipantDetails(participant.id)}
                                    >
                                      {isExpanded ? "Hide details" : "See details"}
                                    </Button>
                                    <Checkbox
                                      checked={selectedParticipants.includes(participant.id)}
                                      onCheckedChange={() => toggleParticipant(participant.id)}
                                      aria-label={`Select ${participant.name || participant.email || `participant ${participant.id}`}`}
                                    />
                                  </div>
                                </div>
                                {isExpanded ? (
                                  <div className="space-y-2 rounded-md border bg-muted/40 p-2 text-xs">
                                    {hasAssignments ? (
                                      assignments.map((assignment) => (
                                        <div
                                          key={assignment.assignmentId}
                                          className="flex flex-col gap-2 rounded-md bg-background/70 p-2 md:flex-row md:items-center md:justify-between"
                                        >
                                          <div>
                                            <p className="font-medium text-foreground">{assignment.assessmentTitle}</p>
                                            <p className="text-[11px] text-muted-foreground">
                                              Updated {formatDateTime(assignment.updatedAt || assignment.createdAt, "—")}
                                            </p>
                                          </div>
                                          <div className="flex flex-wrap gap-2">
                                            <Badge className={statusToneClass(assignment.status)}>
                                              {humanize(assignment.status)}
                                            </Badge>
                                            <Badge className={decisionToneClass(assignment.decision)}>
                                              {decisionLabel(assignment.decision)}
                                            </Badge>
                                          </div>
                                        </div>
                                      ))
                                    ) : (
                                      <p className="text-muted-foreground">
                                        This participant has not been added to a competency quiz yet.
                                      </p>
                                    )}
                                  </div>
                                ) : null}
                              </div>
                            );
                          })
                  ) : (
                    <p className="py-6 text-center text-xs text-muted-foreground">
                      No competency participants match this search.
                    </p>
                  )}
                </div>
              </div>
            </>
          ) : null}

          {currentStep === 3 ? (
            <>
              {recentlyAssignedParticipants.length > 0 ? (
                <div
                  className="space-y-1 rounded-md border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-900"
                  data-testid="participant-assignment-summary"
                >
                  <p className="font-semibold text-emerald-900">Participants assigned</p>
                  <p>You assigned {assignedParticipantSummary} to this study.</p>
                </div>
              ) : null}
              <div className="space-y-2">
                <Label>Launch notes</Label>
                <Textarea
                  placeholder="Add instructions for the research ops team or your co-researcher."
                  value={notes}
                  onChange={(event) => setNotes(event.target.value)}
                />
              </div>
              <div className="space-y-2 rounded-md border p-4 text-sm">
                <p className="font-medium">Pre-launch checklist</p>
                <ul className="list-disc space-y-1 pl-5 text-muted-foreground">
                  <li>Review criteria weights and ensure they total 100%.</li>
                  <li>Confirm competency assessment is published.</li>
                  <li>Let participants know about the study in Slack.</li>
                </ul>
              </div>
              {error ? <p className="text-sm text-destructive">{error}</p> : null}
            </>
          ) : null}
        </CardContent>
        <CardFooter className="flex flex-wrap items-center justify-between gap-3">
          <div className="text-sm text-muted-foreground">
            Need to pause? You can come back later — we auto-save everything locally.
          </div>
          <div className="flex flex-wrap gap-3">
            <Button variant="outline" onClick={goBack} disabled={currentStep === 0}>
              Back
            </Button>
            <Button onClick={primaryAction}>{primaryLabel}</Button>
          </div>
        </CardFooter>
      </Card>

      <Dialog
        open={isDialogOpen}
        onOpenChange={(open) => {
          setIsDialogOpen(open);
          if (!open) {
            resetCriterionDialog();
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingCriterionIndex === null ? "Add new evaluation criterion" : "Edit evaluation criterion"}
            </DialogTitle>
            <DialogDescription>
              Participants will rate this dimension during the study. Adjust weights to keep totals at 100%.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="criterion-name" className="sr-only">
                Criterion name
              </Label>
              <Input
                id="criterion-name"
                placeholder="e.g., Cohesion, Effort to apply"
                value={newCriterionText}
                onChange={(event) => setNewCriterionText(event.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="criterion-weight" className="sr-only">
                Weight
              </Label>
              <Input
                id="criterion-weight"
                type="number"
                min="5"
                max="100"
                placeholder="10"
                value={newCriterionWeight}
                onChange={(event) => setNewCriterionWeight(event.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsDialogOpen(false);
                resetCriterionDialog();
              }}
            >
              Cancel
            </Button>
            <Button onClick={handleSaveCriterion}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <StudyCreationSuccessDialog
        isOpen={isSuccessDialogOpen}
        onClose={() => setIsSuccessDialogOpen(false)}
        study={newlyCreatedStudy}
      />
    </div>
  );
}

export default StudyCreationWizard;
