import React, { useEffect, useState, useCallback, useMemo } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import api from "@/api/axios";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { AlertCircle, CheckCircle2, Eye, RefreshCcw, Timer, Sparkles, Loader2, Trash2, Zap, AlertCircle as AlertCircleIcon } from "lucide-react";

const STATUS_OPTIONS = [
  { value: "all", label: "All" },
  { value: "pending", label: "Pending" },
  { value: "in_review", label: "In review" },
  { value: "resolved", label: "Resolved" },
];
const HIDDEN_FILTER_VALUE = "__hidden__";
const HIDDEN_STORAGE_KEY = "reviewerHiddenAdjudicationIds";

const DECISION_OPTIONS = [
  { value: "participant_correct", label: "Participant correct" },
  { value: "llm_correct", label: "LLM correct" },
  { value: "inconclusive", label: "Inconclusive" },
  { value: "needs_followup", label: "Needs follow-up" },
];

const STAGE_LABELS = {
  stage1: "Stage 1: Bug labeling",
  solid: "SOLID review",
  patch: "Patch/Clone check",
  snapshot: "Snapshot intent",
  custom: "Custom stage",
};

const getStageLabel = (mode) =>
  mode === "stage2" ? STAGE_LABELS.stage1 : STAGE_LABELS[mode] || mode || "—";
const BLINDED_PLACEHOLDER = "Hidden for blinded review";

const BUG_CATEGORIES = [
  "Configuration Issue",
  "Network Issue",
  "Authentication/Authorization Bug",
  "Data Inconsistency",
  "Performance Issue",
  "UI/UX Glitch",
  "Security Vulnerability",
  "Compatibility Issue",
  "Logic Error",
  "Integration Issue",
  "Typo/Content Error",
];

const PATCHES_ARE_CLONES = [
  "yes",
  "no"
]

const SOLID_VIOLATIONS = [
  { id: "srp", label: "SRP – Single Responsibility Principle" },
  { id: "ocp", label: "OCP – Open/Closed Principle" },
  { id: "lsp", label: "LSP – Liskov Substitution Principle" },
  { id: "isp", label: "ISP – Interface Segregation Principle" },
  { id: "dip", label: "DIP – Dependency Inversion Principle" },
];

const COMPLEXITY_LEVELS = ["EASY", "MEDIUM", "HARD"];

/** Clone categories for patch mode */
const PATCH_CLONE_TYPES = [
  { id: "type1", label: "Type-1 – Exact (whitespace/comments only)" },
  { id: "type2", label: "Type-2 – Same structure, different identifiers" },
  { id: "type3", label: "Type-3 – Copied with added/removed/modified lines" },
  { id: "type4", label: "Type-4 – Semantically similar, different implementation"},
];

/** Snapshot study outcomes */
const SNAPSHOT_OUTCOMES = [
  { id: "failure", label: "Actual failure" },
  { id: "intended", label: "Intended UI change" },
  { id: "unclear", label: "Unclear / not sure" },
];

const SNAPSHOT_CHANGE_TYPES = [
  { id: "color", label: "Color / theme change" },
  { id: "layout", label: "Layout or spacing shift" },
  { id: "text", label: "Copy / text update" },
  { id: "icon", label: "Iconography or asset swap" },
  { id: "content", label: "Missing or extra content" },
  { id: "animation", label: "Animation / interaction regression" },
  { id: "other", label: "Other (describe)" },
];

const normalizeCriteriaRatings = (payload) => {
  console.log(payload);
  if (!payload || typeof payload !== "object") return [];
  const candidates = [
    payload.criteriaRatings,
    payload.criteria_scores,
    payload.criteriaScores,
    payload.criteria,
  ].find((arr) => Array.isArray(arr) && arr.length);

  if (candidates) {
    return candidates
      .map((item, idx) => {
        const label =
          item?.label ||
          item?.name ||
          item?.title ||
          item?.criterion ||
          item?.criteria ||
          `Criterion ${idx + 1}`;
        const weight =
          typeof item?.weight !== "undefined"
            ? item.weight
            : typeof item?.weightPercent !== "undefined"
              ? item.weightPercent
              : null;
        const rating =
          typeof item?.rating !== "undefined"
            ? item.rating
            : typeof item?.score !== "undefined"
              ? item.score
              : typeof item?.value !== "undefined"
                ? item.value
                : null;
        return { label, weight, rating };
      })
      .filter((item) => item.label);
  }

  // Support object-based maps from participant payload
  const starMap = payload.evaluationStarRatings && typeof payload.evaluationStarRatings === "object"
    ? payload.evaluationStarRatings
    : null;
  const weightedMap = payload.evaluationRatings && typeof payload.evaluationRatings === "object"
    ? payload.evaluationRatings
    : null;

  if (starMap) {
    return Object.entries(starMap).map(([label, rawRating]) => {
      const rating = Number(rawRating);
      let weight = null;
      if (weightedMap && weightedMap[label] != null && Number.isFinite(Number(weightedMap[label])) && Number.isFinite(rating) && rating !== 0) {
        const pct = Number(weightedMap[label]);
        // pct = weight% * rating / 5  => weight% = pct * 5 / rating
        weight = Number(((pct * 5) / rating).toFixed(2));
      }
      return { label, rating, weight };
    });
  }

  return [];
};

const summarizeCriteriaRatings = (criteria = []) => {
  if (!criteria.length) {
    return { weighted: null, weightTotal: 0, items: [] };
  }
  const weightSum = criteria.reduce(
    (sum, c) => sum + (Number(c.weight) || 0),
    0,
  );
  let weightedScore = 0;
  criteria.forEach((c) => {
    const rating = Number(c.rating);
    if (!Number.isFinite(rating)) return;
    const weight = Number(c.weight) || 0;
    if (weightSum > 0) {
      weightedScore += rating * (weight / 100);
    }
  });
  return {
    weighted: weightSum > 0 ? Number(weightedScore.toFixed(2)) : null,
    weightTotal: weightSum,
    items: criteria,
  };
};

export default function ReviewerAdjudication() {
  const navigate = useNavigate();
  const location = useLocation();
  const [user, setUser] = useState(null);
  const isReviewer = user?.role === "reviewer";
  const [authToken, setAuthToken] = useState(null);
  const [adjudications, setAdjudications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filters, setFilters] = useState({
    status: "all",
    studyId: "all",
    sortBy: "newest",
    participantType: "all",
    showHidden: false,
  });
  const [hiddenIds, setHiddenIds] = useState(() => {
    try {
      const raw = window.localStorage.getItem(HIDDEN_STORAGE_KEY);
      const parsed = JSON.parse(raw || "[]");
      if (Array.isArray(parsed)) {
        return parsed.map((id) => String(id));
      }
    } catch {
      // ignore parse errors
    }
    return [];
  });
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selected, setSelected] = useState(null);
  const [decisionForm, setDecisionForm] = useState({
    status: "pending",
    decision: "__none",
    adjudicatedLabel: "",
    notes: "",
  });
  const [feedbackForm, setFeedbackForm] = useState({ comment: "", rating: "none" });
  const [noteSaving, setNoteSaving] = useState(false);
  const [deletingNoteId, setDeletingNoteId] = useState(null);
  const [formError, setFormError] = useState("");
  const [savingDecision, setSavingDecision] = useState(false);
  const [aiSummary, setAiSummary] = useState("");
  const [aiSummaryLoading, setAiSummaryLoading] = useState(false);
  const [aiSummaryError, setAiSummaryError] = useState("");
  const [aiEvaluationLoading, setAiEvaluationLoading] = useState(false);
  const [aiEvaluationResult, setAiEvaluationResult] = useState(null); // Placeholder for AI evaluation result
  const [aiEvaluationError, setAiEvaluationError] = useState("");
  const [artifactSummaries, setArtifactSummaries] = useState({
    primary: { text: "", loading: false, error: "" },
    secondary: { text: "", loading: false, error: "" },
  });
  const [visibleCount, setVisibleCount] = useState(10);
  const [pendingEvaluationId, setPendingEvaluationId] = useState(() => {
    const stateId = location.state?.openEvaluationId;
    return stateId ? String(stateId) : null;
  });
  const [pendingStudyId, setPendingStudyId] = useState(() => {
    const studyId = location.state?.fallbackStudyId;
    return studyId ? String(studyId) : null;
  });

  useEffect(() => {
    if (location.state?.openEvaluationId || location.state?.fallbackStudyId) {
      setPendingEvaluationId(
        location.state?.openEvaluationId ? String(location.state.openEvaluationId) : null,
      );
      setPendingStudyId(
        location.state?.fallbackStudyId ? String(location.state.fallbackStudyId) : null,
      );
      navigate(location.pathname, { replace: true });
    }
  }, [location.state, location.pathname, navigate]);

  useEffect(() => {
    setVisibleCount(10);
  }, [
    filters.status,
    filters.studyId,
    filters.sortBy,
    filters.participantType,
    filters.showHidden,
    adjudications,
    hiddenIds,
  ]);

  useEffect(() => {
    try {
      window.localStorage.setItem(HIDDEN_STORAGE_KEY, JSON.stringify(hiddenIds));
    } catch {
      // ignore storage failures
    }
  }, [hiddenIds]);

  const hasSubmittedNote = useMemo(() => {
    if (!isReviewer || !selected || !user?.id) return false;
    const comments = Array.isArray(selected.review?.comments) ? selected.review.comments : [];
    return comments.some((note) => String(note.reviewer?.id || "") === String(user.id));
  }, [isReviewer, selected, user?.id]);

  const canDeleteNote = useCallback(
    (note) => {
      if (!note) return false;
      const reviewerId = note.reviewer?.id || note.reviewerId;
      if (isReviewer && reviewerId && String(reviewerId) === String(user?.id)) {
        return true;
      }
      if ((user?.role === "researcher" || user?.role === "admin") && selected?.study?.researcherId) {
        return String(selected.study.researcherId) === String(user.id);
      }
      return user?.role === "admin";
    },
    [isReviewer, selected?.study?.researcherId, user?.id, user?.role],
  );

  const buildReviewSummaryPrompt = useCallback((entry) => {
    if (!entry) return "";

    const describePane = (pane, label) => {
      if (!pane) return `${label}: missing.`;
      const kind = (pane.type || "").toLowerCase();
      const name = pane.name || label;
      if (kind === "text") {
        const text = pane.text || "";
        const trimmed = text.length > 1200 ? `${text.slice(0, 1200)}... [truncated]` : text;
        return `${label} (${name}, text):\n${trimmed}`;
      }
      if (kind === "image" || kind === "pdf") {
        return `${label} (${name}, ${kind}) was uploaded.`;
      }
      return `${label} (${name}, ${kind || "unknown"}).`;
    };

    const lines = [];
    lines.push(
      `Study: ${entry.study?.title || "Study"} (id: ${entry.study?.id || "n/a"})`,
    );
    const isBlindedStudy = Boolean(entry.study?.isBlinded);
    const participantName = entry.participant?.name || "Participant";
    const participantEmail = isBlindedStudy ? BLINDED_PLACEHOLDER : entry.participant?.email || "n/a";
    const submittedStamp = formatDateTime(entry.submittedAt);
    lines.push(
      `Participant: ${participantName} (${participantEmail}); submitted at ${submittedStamp}.`,
    );
    lines.push(
      `Review status: ${entry.review?.status || "pending"}; decision: ${entry.review?.decision || "none"}; adjudicated label: ${entry.review?.adjudicatedLabel || "n/a"}.`,
    );
    if (entry.comparison) {
      lines.push(
        `Artifacts compared: Primary ${entry.comparison.primary?.artifactName || entry.comparison.primary?.label || "N/A"} vs Secondary ${entry.comparison.secondary?.artifactName || entry.comparison.secondary?.label || "N/A"}. Prompt: ${entry.comparison.prompt || "none"}.`,
      );
    }
    const answer = entry.participantAnswer || {};
    const payload = answer.payload || {};
    const mode = payload.mode || answer.mode || null;
    const normalizedMode = mode === "stage2" ? "stage1" : mode;
    const metrics = answer.metrics || {};
    const preference = answer.preference || payload.preference || "n/a";
    const rating = (answer.rating ?? payload.rating ?? "n/a");
    const summary = answer.summary || payload.summary || "";
    const notes = answer.notes || payload.notes || payload.assessmentComment || "";
    const snapshotDiff = payload.snapshotDiffData
      ? `Diff artifact provided (${payload.snapshotDiffData.name || payload.snapshotDiffData.type || "diff"}).`
      : "";
    lines.push(
      `Participant preference: ${preference}; rating: ${rating}. Summary: ${summary || "—"}. Notes: ${notes || "—"}. ${snapshotDiff}`,
    );
    lines.push(`Stage: ${getStageLabel(normalizedMode)}`);
    // Include stage-specific answers
    if (normalizedMode === "stage1") {
      lines.push(`Bug category: ${payload.leftCategory || "—"}`);
      if (payload.assessmentComment) lines.push(`Notes: ${payload.assessmentComment}`);
    } else if (normalizedMode === "solid") {
      lines.push(`Violation: ${payload.solidViolation || payload.solid_violation || "—"}`);
      lines.push(`Complexity: ${payload.solidComplexity || payload.solid_complexity || "—"}`);
      lines.push(`Refactor: ${payload.solidFixedCode || payload.solid_fixed_code || "—"}`);
      if (payload.assessmentComment) lines.push(`Notes: ${payload.assessmentComment}`);
    } else if (normalizedMode === "patch") {
      lines.push(`Are patches clones? ${payload.patchAreClones || "—"}`);
      if (payload.patchAreClones === "yes") {
        lines.push(`Clone type: ${payload.patchCloneType || "—"}`);
      }
      if (payload.patchCloneComment) lines.push(`Notes: ${payload.patchCloneComment}`);
    } else if (normalizedMode === "snapshot") {
      lines.push(`Outcome: ${payload.snapshotOutcome || "—"}`);
      const changeType =
        payload.snapshotChangeType === "other"
          ? payload.snapshotChangeTypeOther || "Other (unspecified)"
          : payload.snapshotChangeType || "—";
      lines.push(`Change type: ${changeType}`);
      if (payload.assessmentComment) lines.push(`Notes: ${payload.assessmentComment}`);
    } else if (normalizedMode === "custom") {
      const responses =
        payload.customResponses && typeof payload.customResponses === "object"
          ? payload.customResponses
          : {};
      const questions = Array.isArray(payload.customQuestions) ? payload.customQuestions : [];
      if (questions.length === 0) {
        lines.push("Custom responses: none provided.");
      } else {
        questions.forEach((q, idx) => {
          const answer = responses[q.id] ?? "—";
          lines.push(`Q${idx + 1}: ${q.prompt} → ${answer}`);
        });
      }
      if (payload.assessmentComment) lines.push(`Notes: ${payload.assessmentComment}`);
    }
    // Include participant-provided panes for LLM context
    lines.push(describePane(payload.left, "Artifact A (pane)"));
    lines.push(describePane(payload.right, "Artifact B (pane)"));
    if (Object.keys(metrics).length) {
      lines.push(`Metrics: ${JSON.stringify(metrics)}`);
    }
    lines.push(`Raw payload keys: ${Object.keys(payload).join(", ") || "none"}`);
    lines.push("Produce 2-3 crisp bullets covering submission quality, risks, and next steps.");
    return lines.join("\n");
  }, []);

  useEffect(() => {
    const rawUser = localStorage.getItem("user");
    const token = localStorage.getItem("token");
    if (!rawUser || !token) {
      navigate("/login");
      return;
    }
    try {
      const parsed = JSON.parse(rawUser);
      if (parsed.role !== "researcher" && parsed.role !== "admin" && parsed.role !== "reviewer") {
        navigate("/login");
        return;
      }
      setUser(parsed);
      setAuthToken(token);
    } catch (err) {
      console.error("Failed to parse user", err);
      navigate("/login");
    }
  }, [navigate]);

  const fetchAdjudications = useCallback(async () => {
    if (!authToken) return;
    setLoading(true);
    setError("");
    try {
      const params = new URLSearchParams();
      if (filters.status) {
        params.append("status", filters.status);
      }
      if (filters.studyId && filters.studyId !== "all" && filters.studyId !== HIDDEN_FILTER_VALUE) {
        params.append("studyId", filters.studyId);
      }
      const query = params.toString();
      const endpoint = query ? `/api/reviewer/adjudications?${query}` : "/api/reviewer/adjudications";
      const { data } = await api.get(endpoint, {
        headers: {
          Authorization: `Bearer ${authToken}`,
        },
      });
      setAdjudications(data?.adjudications || []);
    } catch (err) {
      console.error("Failed to load adjudications", err);
      const message = err.response?.data?.message || "Unable to load reviewer queue right now.";
      setError(message);
      setAdjudications([]);
    } finally {
      setLoading(false);
    }
  }, [authToken, filters]);

  useEffect(() => {
    fetchAdjudications();
  }, [fetchAdjudications]);

  useEffect(() => {
    if (pendingEvaluationId && adjudications.length) {
      const entry = adjudications.find(
        (item) => String(item.id) === String(pendingEvaluationId),
      );
      if (entry) {
        openDialog(entry);
        setPendingEvaluationId(null);
        setPendingStudyId(null);
        return;
      }
    }
    if (pendingStudyId && adjudications.length && !pendingEvaluationId) {
      const entry = adjudications.find(
        (item) => item.study && String(item.study.id) === String(pendingStudyId),
      );
      if (entry) {
        openDialog(entry);
        setPendingStudyId(null);
      }
    }
  }, [pendingEvaluationId, pendingStudyId, adjudications]);

  const studyOptions = useMemo(() => {
    const uniq = new Map();
    adjudications.forEach((entry) => {
      if (entry.study) {
        uniq.set(entry.study.id, entry.study.title || `Study ${entry.study.id}`);
      }
    });
    return Array.from(uniq.entries()).map(([id, title]) => ({ id, title }));
  }, [adjudications]);

  const statusCounts = useMemo(() => {
    return adjudications.reduce(
      (acc, entry) => {
        const status = entry.review?.status || "pending";
        acc[status] = (acc[status] || 0) + 1;
        return acc;
      },
      { pending: 0, in_review: 0, resolved: 0 }
    );
  }, [adjudications]);

  const filteredAdjudications = useMemo(() => {
    let list = adjudications;
    if (filters.participantType === "guest") {
      list = list.filter((entry) => {
        const participant = entry?.participant || {};
        const role = String(participant.role || "").toLowerCase();
        const email = String(participant.email || "");
        return participant.isGuest === true || role === "guest" || /guest/i.test(email);
      });
    }
    const effectiveShowHidden = filters.showHidden || filters.studyId === HIDDEN_FILTER_VALUE;
    if (!effectiveShowHidden) {
      list = list.filter((entry) => !hiddenIds.includes(String(entry.id)));
    }
    if (filters.studyId === HIDDEN_FILTER_VALUE) {
      list = list.filter((entry) => hiddenIds.includes(String(entry.id)));
    }
    return list;
  }, [adjudications, filters.participantType, filters.showHidden, filters.studyId, hiddenIds]);

  const sortedAdjudications = useMemo(() => {
    const resolveTimestamp = (entry) => {
      const candidate =
        entry?.submittedAt ||
        entry?.participantAnswer?.submittedAt ||
        entry?.participantAnswer?.createdAt ||
        entry?.createdAt ||
        entry?.review?.createdAt;
      const date = candidate ? new Date(candidate) : null;
      return date && !Number.isNaN(date.getTime()) ? date.getTime() : 0;
    };
    const resolveName = (entry) => {
      const participant = entry?.participant || {};
      return String(participant.name || participant.email || "").toLowerCase();
    };
    const list = [...filteredAdjudications];
    if (filters.sortBy === "oldest") {
      return list.sort((a, b) => resolveTimestamp(a) - resolveTimestamp(b));
    }
    if (filters.sortBy === "name") {
      return list.sort((a, b) => resolveName(a).localeCompare(resolveName(b)) || resolveTimestamp(b) - resolveTimestamp(a));
    }
    return list.sort((a, b) => resolveTimestamp(b) - resolveTimestamp(a));
  }, [filteredAdjudications, filters.sortBy]);

  const visibleAdjudications = useMemo(
    () => sortedAdjudications.slice(0, visibleCount),
    [sortedAdjudications, visibleCount],
  );

  const openDialog = (entry) => {
    setSelected(entry);
    const existingNote =
      isReviewer && user?.id
        ? (entry.review?.comments || []).find(
            (note) => String(note.reviewer?.id || "") === String(user.id),
          )
        : null;
    setDecisionForm({
      status: entry.review?.status || "pending",
      decision: entry.review?.decision || "__none",
      adjudicatedLabel: entry.review?.adjudicatedLabel || "",
      notes: entry.review?.notes || "",
    });
    setFeedbackForm({
      comment: existingNote?.comment || entry.review?.comment || "",
      rating:
        existingNote?.rating != null
          ? String(existingNote.rating)
          : isReviewer
            ? "none"
            : entry.review?.rating != null
              ? String(entry.review.rating)
              : "none",
    });
    setFormError("");
    setAiSummary("");
    setAiSummaryError("");
    setAiSummaryLoading(false);
    setArtifactSummaries({
      primary: { text: "", loading: false, error: "" },
      secondary: { text: "", loading: false, error: "" },
    });
    setDialogOpen(true);
  };

  const closeDialog = () => {
    setDialogOpen(false);
    setSelected(null);
    setFormError("");
    setFeedbackForm({ comment: "", rating: "none" });
    setNoteSaving(false);
    setDeletingNoteId(null);
    setAiEvaluationResult(null);
  };

  const handleDecisionChange = (field, value) => {
    setDecisionForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleFeedbackChange = (field, value) => {
    setFeedbackForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleGenerateAiSummary = async () => {
    if (!selected) {
      return;
    }
    setAiSummaryLoading(true);
    setAiSummaryError("");
    try {
      const prompt = buildReviewSummaryPrompt(selected);
      const { data } = await api.post("/api/llm", {
        key: "REVIEW_SUMMARY",
        prompt,
        id: selected.id, // pass evaluation id so backend can attach artifacts
      });
      setAiSummary(data?.response || "No summary returned.");
    } catch (err) {
      console.error("AI summary error", err);
      const message = err.response?.data?.error || "Unable to generate AI summary right now.";
      setAiSummaryError(message);
    } finally {
      setAiSummaryLoading(false);
    }
  };

  const handleArtifactSummary = async (key, artifactMeta) => {
    if (!selected) return;
    if (!artifactMeta?.artifactId) {
      setArtifactSummaries((prev) => ({
        ...prev,
        [key]: { ...prev[key], error: "Artifact id missing for summary." },
      }));
      return;
    }
    setArtifactSummaries((prev) => ({
      ...prev,
      [key]: { ...prev[key], loading: true, error: "" },
    }));

    const participantMode =
      selected.participantAnswer?.payload?.mode || selected.participantAnswer?.mode || null;
    const stageLabel = getStageLabel(participantMode);
    const artifactLabel = artifactMeta.artifactName || artifactMeta.label || `Artifact ${key}`;

    try {
      const prompt = [
        `Summarize the attached artifact "${artifactLabel}" for study review.`,
        `Stage: ${stageLabel}.`,
        "Provide 2-3 crisp bullets describing what the artifact contains and any notable issues or risks.",
      ].join(" ");

      const { data } = await api.post("/api/llm", {
        key: "ARTIFACT_SUMMARY",
        prompt,
        id: artifactMeta.artifactId,
      });

      setArtifactSummaries((prev) => ({
        ...prev,
        [key]: { text: data?.response || "No summary returned.", loading: false, error: "" },
      }));
    } catch (err) {
      console.error("Artifact summary error", err);
      const message = err.response?.data?.error || "Unable to summarize this artifact right now.";
      setArtifactSummaries((prev) => ({
        ...prev,
        [key]: { ...prev[key], loading: false, error: message },
      }));
    }
  };

  const handleGenerateAiEvaluation = async () => {
    if (!selected) {
      return;
    }
    setAiEvaluationLoading(true);
    setAiEvaluationError("");
    setAiEvaluationResult(null);

    // Placeholder for actual AI evaluation API call
    try {
      const mode = selected.participantAnswer.payload.mode;
      let prompt = "";

      switch (mode) {
        case "stage1":
          console.log("Generating AI evaluation for bug adjudication:", selected.id);
          prompt = "QUESTION 1: Select bug category\n";
          BUG_CATEGORIES.forEach((category, index) => {
            prompt += `${index + 1}) ${category}\n`;
          });
          break;
        case "solid":
          console.log("Generating AI evaluation for SOLID adjudication:", selected.id);
          prompt = "QUESTION 1: Select SOLID violation present\n";
          SOLID_VIOLATIONS.forEach((category, index) => {
            prompt += `${index + 1}) ${category.label}\n`;
          });

          prompt += "QUESTION 2: Select complexity level\n";
          COMPLEXITY_LEVELS.forEach((level, index) => {
            prompt += `${index + 1}) ${level}\n`;
          });

          prompt += "QUESTION 3 (Open ended): Give fixed version of the code\n";
          break;
        case "patch":
          prompt = "QUESTION 1: Are the given artifacts clones/similar?\n"
          prompt += "1) Yes\n";
          prompt += "2) No\n";

          prompt += "QUESTION 2: How do the artifacts relate?\n"
          PATCH_CLONE_TYPES.forEach((type, index) => {
            prompt += `${index + 1}) ${type.label}\n`;
          });
          break;
        case "snapshot":
          prompt += "QUESTION 1: Given the before/after, what is the outcome of the change?\n";
          SNAPSHOT_OUTCOMES.forEach((type, index) => {
            prompt += `${index + 1}) ${type.label}\n`;
          });
          prompt += "QUESTION 2: What has been changed?\n";
          SNAPSHOT_CHANGE_TYPES.forEach((type, index) => {
            prompt += `${index + 1}) ${type.label}\n`;
          });
          break;
        case "custom":
          selected.participantAnswer.payload.customQuestions.forEach((question, index) => {
            if (question.type === "answer"){
              prompt += `QUESTION ${index + 1} (Open ended): ${question.prompt}\n`;
            } else {
              prompt += `QUESTION ${index + 1}: ${question.prompt}\n`;
            }
            question.options.forEach((option, index) => {
              prompt += `${index + 1}) ${option}\n`;
            });
          })
          break;
      }
      prompt += "\nCRITERIA:\n";
      const criteria = normalizeCriteriaRatings(selected.participantAnswer.payload);
      criteria.forEach((criterion, index) => {
        prompt += `${index + 1}) ${criterion.label}\n`;
      });

      const { data } = await api.post("/api/llm", {
        key: "STUDY_ANALYSIS",
        prompt: prompt,
        id: selected.id,
      });

      console.log(data?.response);
      setAiEvaluationResult(data); // Store the entire data object
    } catch (err) {
      console.error("AI evaluation error", err);
      const message = err.response?.data?.error || "Failed to generate AI evaluation.";
      setAiEvaluationError(message);
    } finally {
      setAiEvaluationLoading(false);
    }
  };

  const handleSaveDecision = async () => {
    if (!selected || !authToken) {
      return;
    }
    setSavingDecision(true);
    setFormError("");
    try {
      if (isReviewer) {
        if (hasSubmittedNote) {
          setFormError("You already submitted feedback for this evaluation.");
          setSavingDecision(false);
          return;
        }
        setNoteSaving(true);
        await api.post(
          `/api/reviewer/adjudications/${selected.id}/notes`,
          {
            comment: feedbackForm.comment || "",
            rating: feedbackForm.rating === "none" ? null : Number(feedbackForm.rating),
          },
          { headers: { Authorization: `Bearer ${authToken}` } }
        );
      } else {
        await api.patch(
          `/api/reviewer/adjudications/${selected.id}`,
          {
            reviewStatus: decisionForm.status,
            decision: decisionForm.decision === "__none" ? undefined : decisionForm.decision,
            adjudicatedLabel: decisionForm.adjudicatedLabel || null,
            notes: decisionForm.notes || "",
          },
          { headers: { Authorization: `Bearer ${authToken}` } }
        );
      }
      await fetchAdjudications();
      closeDialog();
    } catch (err) {
      console.error("Failed to save adjudication", err);
      const message = err.response?.data?.message || "Unable to save decision right now.";
      setFormError(message);
    } finally {
      setSavingDecision(false);
      setNoteSaving(false);
    }
  };

  const handleRefresh = () => fetchAdjudications();

  const handleShowMore = () => {
    setVisibleCount((prev) => Math.min(prev + 5, sortedAdjudications.length));
  };

  const handleHideRow = (id) => {
    const key = String(id);
    setHiddenIds((prev) => (prev.includes(key) ? prev : [...prev, key]));
  };

  const handleDeleteNote = useCallback(
    async (noteId) => {
      if (!selected || !authToken || !noteId) return;
      setDeletingNoteId(noteId);
      setFormError("");
      try {
        await api.delete(`/api/reviewer/adjudications/${selected.id}/notes/${noteId}`, {
          headers: { Authorization: `Bearer ${authToken}` },
        });
        setSelected((prev) => {
          if (!prev || !prev.review) return prev;
          const nextComments = (prev.review.comments || []).filter((note) => note.id !== noteId);
          return { ...prev, review: { ...prev.review, comments: nextComments } };
        });
        await fetchAdjudications();
      } catch (err) {
        console.error("Failed to delete reviewer note", err);
        const message = err.response?.data?.message || "Unable to delete reviewer note right now.";
        setFormError(message);
      } finally {
        setDeletingNoteId(null);
      }
    },
    [selected, authToken, fetchAdjudications],
  );

  if (!user) {
    return null;
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center p-10">
        <p className="text-muted-foreground text-sm">Loading reviewer queue...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="flex items-start gap-3 rounded-lg border border-red-200 bg-red-50/80 p-4">
          <AlertCircle className="h-5 w-5 text-red-600 mt-0.5" />
          <div>
            <p className="font-semibold text-red-900">{error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={handleRefresh}>
              <RefreshCcw className="mr-2 h-4 w-4" />
              Try again
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const hasRows = sortedAdjudications.length > 0;
  const selectedParticipantDisplay = selected ? getParticipantDisplayMeta(selected) : null;
  const canShowMore = visibleCount < sortedAdjudications.length;

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6 p-6 md:p-10">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-semibold">Reviewer adjudication</h1>
        <p className="text-sm text-muted-foreground">
          Compare participant submissions against LLM ground truth and record the final decision for each evaluation.
        </p>
        <p className="text-xs text-muted-foreground">
          You will only see studies where the researcher enabled reviewer feedback.
        </p>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <div>
            <CardTitle>Queue status</CardTitle>
            <CardDescription>Monitor how many evaluations await adjudication.</CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={handleRefresh}>
            <RefreshCcw className="mr-2 h-4 w-4" />
            Refresh
          </Button>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            <StatusTile icon={Timer} label="Pending" value={statusCounts.pending} tone="amber" />
            <StatusTile icon={Eye} label="In review" value={statusCounts.in_review} tone="blue" />
            <StatusTile icon={CheckCircle2} label="Resolved" value={statusCounts.resolved} tone="green" />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Filters</CardTitle>
          <CardDescription>Narrow the queue to the study or status you care about.</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium">Review status</label>
            <Select value={filters.status} onValueChange={(value) => setFilters((prev) => ({ ...prev, status: value }))}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Pick status" />
              </SelectTrigger>
              <SelectContent>
                {STATUS_OPTIONS.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium">Study</label>
            <Select
              value={filters.studyId}
              onValueChange={(value) =>
                setFilters((prev) => ({
                  ...prev,
                  studyId: value,
                  showHidden: value === HIDDEN_FILTER_VALUE ? true : prev.showHidden,
                }))
              }
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="All studies" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All studies</SelectItem>
                <SelectItem value={HIDDEN_FILTER_VALUE}>Hidden rows</SelectItem>
                {studyOptions.map((option) => (
                  <SelectItem key={option.id} value={option.id}>
                    {option.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium">Sort by</label>
            <Select
              value={filters.sortBy}
              onValueChange={(value) => setFilters((prev) => ({ ...prev, sortBy: value }))}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Sort order" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Submission time (newest first)</SelectItem>
                <SelectItem value="oldest">Submission time (oldest first)</SelectItem>
                <SelectItem value="name">Participant name (A-Z)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium">Participant</label>
            <Select
              value={filters.participantType}
              onValueChange={(value) => setFilters((prev) => ({ ...prev, participantType: value }))}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="All participants" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All participants</SelectItem>
                <SelectItem value="guest">Guest users only</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {!hasRows ? (
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">
              No evaluations found for the selected filters. Assign artifact comparisons to participants and their submissions will appear here once ready.
            </p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Evaluations</CardTitle>
            <CardDescription>Review each submission and finalize the adjudication.</CardDescription>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Participant</TableHead>
                  <TableHead>Study</TableHead>
                  <TableHead>Submitted</TableHead>
                  <TableHead>Review status</TableHead>
                  <TableHead>Decision</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {visibleAdjudications.map((entry) => {
                  const participantDisplay = getParticipantDisplayMeta(entry);
                  const isHidden = hiddenIds.includes(String(entry.id));
                  return (
                    <TableRow key={entry.id} className={isHidden ? "opacity-60" : ""}>
                      <TableCell className="font-medium">
                        <div className="flex flex-col gap-1">
                          <div className="flex items-center gap-2">
                            <span>{participantDisplay.name}</span>
                            {participantDisplay.isBlinded ? <Badge variant="outline">Blinded</Badge> : null}
                            {isHidden ? <Badge variant="secondary">Hidden</Badge> : null}
                          </div>
                          <p className="text-xs text-muted-foreground">{participantDisplay.email}</p>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {entry.study?.title || "Study"}
                      </TableCell>
                      <TableCell className="text-sm">
                        {participantDisplay.submittedLabel}
                      </TableCell>
                      <TableCell>{getStatusBadge(entry.review?.status)}</TableCell>
                      <TableCell>{getDecisionBadge(entry.review?.decision)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="outline" size="sm" onClick={() => openDialog(entry)}>
                            <Eye className="mr-2 h-4 w-4" />
                            Review
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-destructive"
                            onClick={() => handleHideRow(entry.id)}
                          >
                            Hide
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
            <div className="flex items-center justify-between pt-4">
              <p className="text-xs text-muted-foreground">
                Showing {Math.min(visibleCount, sortedAdjudications.length)} of {sortedAdjudications.length}
              </p>
              {canShowMore ? (
                <Button variant="ghost" size="sm" onClick={handleShowMore}>
                  Show more
                </Button>
              ) : null}
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={(open) => (open ? null : closeDialog())}>
        <DialogContent className="max-w-3xl max-h-[95vh] overflow-y-auto">
          {selected && (
            <>
              {selected.review?.status === "resolved" && !isReviewer && (
                <div className="mb-3 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs text-emerald-800">
                  This review is already completed. Edits are disabled.
                </div>
              )}

              <DialogHeader>
                <DialogTitle>Adjudicate evaluation</DialogTitle>
                <DialogDescription>
                  {selectedParticipantDisplay?.name || selected.participant?.name || "Participant"} •{" "}
                  {selected.study?.title || "Study"}
                </DialogDescription>
              </DialogHeader>

              {selectedParticipantDisplay?.isBlinded ? (
                <div className="mb-3 rounded-md border border-dashed border-muted px-3 py-2 text-xs text-muted-foreground">
                  Participant identity is hidden for this blinded evaluation.
                </div>
              ) : null}

              <section className="space-y-4">
                <h3 className="text-sm font-semibold text-muted-foreground">Comparison overview</h3>
                <ComparisonSummary comparison={selected.comparison} />
              </section>

              <section className="space-y-3">
                <h3 className="text-sm font-semibold text-muted-foreground">Artifact AI summaries</h3>
                <div className="grid gap-3 md:grid-cols-2">
                  <ArtifactSummaryCard
                    title="Primary artifact"
                    artifact={selected.comparison?.primary}
                    summary={artifactSummaries.primary}
                    onGenerate={() => handleArtifactSummary("primary", selected.comparison?.primary)}
                  />
                  <ArtifactSummaryCard
                    title="Secondary artifact"
                    artifact={selected.comparison?.secondary}
                    summary={artifactSummaries.secondary}
                    onGenerate={() => handleArtifactSummary("secondary", selected.comparison?.secondary)}
                  />
                </div>
              </section>

              <Separator className="my-4" />

              <section className="space-y-4">
                <h3 className="text-sm font-semibold text-muted-foreground">Participant answer</h3>
                <AnswerSummary answer={selected.participantAnswer} />
              </section>

              <Separator className="my-4" />

              <section className="space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-semibold text-muted-foreground">AI summary</h3>
                    <p className="text-xs text-muted-foreground">
                      Generate a concise summary of this submission for quick review notes.
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleGenerateAiSummary}
                    disabled={aiSummaryLoading}
                  >
                    {aiSummaryLoading ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Sparkles className="mr-2 h-4 w-4" />
                    )}
                    {aiSummaryLoading ? "Generating..." : "Generate AI summary"}
                  </Button>
                </div>
                {aiSummaryError && (
                  <p className="text-xs text-red-600">{aiSummaryError}</p>
                )}
                {aiSummary ? (
                  <div className="rounded-md border p-3 bg-muted/40 text-sm whitespace-pre-wrap">
                    {aiSummary}
                  </div>
                ) : !aiSummaryLoading ? (
                  <p className="text-xs text-muted-foreground">No AI summary yet.</p>
                ) : null}

              </section>

              <Separator className="my-4" />

              <section className="space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-semibold text-muted-foreground">AI evaluation</h3>
                    <p className="text-xs text-muted-foreground">
                      Generate an AI evaluation for this adjudication.
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleGenerateAiEvaluation}
                    disabled={aiEvaluationLoading || !selected}
                  >
                    {aiEvaluationLoading ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Zap className="mr-2 h-4 w-4" />
                    )}
                    {aiEvaluationLoading ? "Generating..." : "Generate AI evaluation"}
                  </Button>
                </div>
                {aiEvaluationResult && (
                  <div className="grid gap-3 md:grid-cols-2 mt-4">
                    {/* Participant's Card */}
                    <div className="rounded-lg border p-4 bg-sky-50">
                      <h4 className="font-semibold text-sm mb-2">Participant's Evaluation</h4>
                      {selected.participantAnswer?.payload?.mode === "stage1" && (
                        <div className="text-sm mt-2 space-y-1">
                          <p>Bug category: {selected.participantAnswer?.payload?.leftCategory || selected.participantAnswer?.payload?.finalCategory || "—"}</p>
                        </div>
                      )}
                      {selected.participantAnswer?.payload?.mode === "solid" && (
                        <div className="text-sm mt-2 space-y-1">
                          <p>Violation: {selected.participantAnswer?.payload?.solidViolation || selected.participantAnswer?.payload?.solid_violation || "—"}</p>
                          <p>Complexity: {selected.participantAnswer?.payload?.solidComplexity || selected.participantAnswer?.payload?.solid_complexity || "—"}</p>
                          <p>Refactor:</p>
                          <Textarea
                            id="generated-artifact"
                            readOnly={true}
                            value={selected.participantAnswer?.payload?.solidFixedCode || selected.participantAnswer?.payload?.solid_fixed_code || "No refactor response."}
                            className="min-h-[150px]"
                          />
                        </div>
                      )}
                      {selected.participantAnswer?.payload?.mode === "patch" && (
                        <div className="text-sm mt-2 space-y-1">
                          <p>Are patches clones? {selected.participantAnswer?.payload?.patchAreClones || "—"}</p>
                          <p>Clone type: {selected.participantAnswer?.payload?.patchCloneType || "—"}</p>
                        </div>
                      )}
                      {selected.participantAnswer?.payload?.mode === "snapshot" && (
                        <div className="text-sm mt-2 space-y-1">
                          <p>Outcome: {selected.participantAnswer?.payload?.snapshotOutcome || "—"}</p>
                          <p>Change type: {selected.participantAnswer?.payload?.snapshotChangeType || "—"}</p>
                        </div>
                      )}
                      {selected.participantAnswer?.payload?.mode === "custom" && (
                        <div className="text-sm mt-2 space-y-1">
                          {(selected.participantAnswer?.payload?.customQuestions || []).map((q) => (
                            <div key={q.id}>
                              <p>{q.prompt}:</p>
                              <p className="text-muted-foreground">{selected.participantAnswer?.payload?.customResponses?.[q.id] || "N/A"}</p>
                            </div>
                          ))}
                        </div>
                      )}
                      <Separator className="my-3" />
                      <p className="text-xs font-semibold text-muted-foreground mb-1">Criteria Scores:</p>
                      <div className="space-y-1">
                        {normalizeCriteriaRatings(selected.participantAnswer.payload).map((item) => (
                          <div key={item.label} className="flex items-center justify-between text-sm">
                            <span>{item.label}:</span>
                            <StarRow value={item.rating} />
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* AI's Card */}
                    <div className="rounded-lg border p-4 bg-muted/40 bg-violet-50">
                      <h4 className="font-semibold text-sm mb-2">AI Evaluation</h4>
                        {selected.participantAnswer?.payload?.mode === "stage1" && (
                          <div className="text-sm mt-2 space-y-1">
                            <p className="flex items-center gap-2">Bug category: {BUG_CATEGORIES[aiEvaluationResult.response.options[0]-1] || "—"}
                              {BUG_CATEGORIES[aiEvaluationResult.response.options[0]-1] !==
                                (selected.participantAnswer?.payload?.leftCategory || selected.participantAnswer?.payload?.finalCategory) && (
                                <AlertCircleIcon className="h-4 w-4 text-orange-500" />
                              )}</p>
                          </div>
                        )}
                        {selected.participantAnswer?.payload?.mode === "solid" && (
                          <div className="text-sm mt-2 space-y-1">
                            <p className="flex items-center gap-2">
                              Violation: {SOLID_VIOLATIONS[aiEvaluationResult.response?.options[0]-1]?.id || "—"}
                              {(SOLID_VIOLATIONS[aiEvaluationResult.response?.options[0]-1]?.id || "") !==
                                (selected.participantAnswer?.payload?.solidViolation || selected.participantAnswer?.payload?.solid_violation || "") && (
                                <AlertCircleIcon className="h-4 w-4 text-orange-500" />
                              )}
                            </p>
                            <p className="flex items-center gap-2">
                              Complexity: {COMPLEXITY_LEVELS[aiEvaluationResult.response?.options[1]-1] || "—"}
                              {(COMPLEXITY_LEVELS[aiEvaluationResult.response?.options[1]-1] || "") !==
                                (selected.participantAnswer?.payload?.solidComplexity || selected.participantAnswer?.payload?.solid_complexity || "") && (
                                <AlertCircleIcon className="h-4 w-4 text-orange-500" />
                              )}
                            </p>
                            <p className="flex items-center gap-2">
                              Refactor:
                            </p>
                            <Textarea
                              id="generated-artifact"
                              readOnly={true}
                              value={aiEvaluationResult.response?.options[2] || "No refactor response."}
                              className="min-h-[150px]"
                            />
                          </div>
                        )}
                        {selected.participantAnswer?.payload?.mode === "patch" && (
                          <div className="text-sm mt-2 space-y-1">
                            <p className="flex items-center gap-2">
                              Are patches clones?: {PATCHES_ARE_CLONES[aiEvaluationResult.response?.options[0]-1] || "—"}
                              {(PATCHES_ARE_CLONES[aiEvaluationResult.response?.options[0]-1] || "") !==
                                (selected.participantAnswer?.payload?.patchAreClones || "") && (
                                <AlertCircleIcon className="h-4 w-4 text-orange-500" />
                              )}
                            </p>
                            <p className="flex items-center gap-2">
                              Clone type: {PATCH_CLONE_TYPES[aiEvaluationResult.response?.options[1]-1]?.id || "—"}
                              {(PATCH_CLONE_TYPES[aiEvaluationResult.response?.options[1]-1]?.id || "") !==
                                (selected.participantAnswer?.payload?.patchCloneType || "") && (
                                <AlertCircleIcon className="h-4 w-4 text-orange-500" />
                              )}
                            </p>
                          </div>
                        )}
                        {selected.participantAnswer?.payload?.mode === "snapshot" && (
                          <div className="text-sm mt-2 space-y-1">
                            <p className="flex items-center gap-2">
                              Outcome: {SNAPSHOT_OUTCOMES[aiEvaluationResult.response?.options[0]-1]?.id || "—"}
                              {(SNAPSHOT_OUTCOMES[aiEvaluationResult.response?.options[0]-1]?.id || "") !==
                                (selected.participantAnswer?.payload?.snapshotOutcome || "") && (
                                <AlertCircleIcon className="h-4 w-4 text-orange-500" />
                              )}
                            </p>
                            <p className="flex items-center gap-2">
                              Change type: {SNAPSHOT_CHANGE_TYPES[aiEvaluationResult.response?.options[1]-1]?.id || "—"}
                              {(SNAPSHOT_CHANGE_TYPES[aiEvaluationResult.response?.options[1]-1]?.id || "") !==
                                (selected.participantAnswer?.payload?.snapshotChangeType || "") && (
                                <AlertCircleIcon className="h-4 w-4 text-orange-500" />
                              )}
                            </p>
                          </div>
                        )}
                        {selected.participantAnswer?.payload?.mode === "custom" && (
                          <div className="text-sm mt-2 space-y-1">
                            <p className="font-semibold mb-1">Custom Questions:</p>
                            {(selected.participantAnswer?.payload?.customQuestions || []).map((q, qIndex) => {
                              const participantAnswer = selected.participantAnswer?.payload?.customResponses?.[q.id] || "N/A";
                              let aiAnswer = "—";
                              const aiOptionIndex = aiEvaluationResult.response?.options?.[qIndex];

                              if (aiOptionIndex !== undefined && aiOptionIndex !== null) {
                                if (q.type === "mcq" || q.type === "dropdown") {
                                  aiAnswer = q.options?.[aiOptionIndex-1] || "N/A";
                                } else if (q.type === "answer") {
                                  aiAnswer = String(aiOptionIndex); // Assuming idx itself is the answer
                                }
                              }

                              const isDifferent = aiAnswer !== participantAnswer;

                              return (
                                <div key={q.id} className="space-y-1">
                                  <p className="font-medium flex items-center gap-2">
                                    {q.prompt}
                                    {(isDifferent && q.type !== "answer") && <AlertCircleIcon className="h-4 w-4 text-orange-500" />}
                                  </p>
                                  <p className="text-muted-foreground">
                                    {aiAnswer}
                                  </p>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      <Separator className="my-3" />
                      <p className="text-xs font-semibold text-muted-foreground mb-1">Criteria Scores:</p>
                      <div className="space-y-1">
                        {normalizeCriteriaRatings(selected.participantAnswer.payload).map((participantCriterion, index) => {
                          const aiScore = aiEvaluationResult.response?.criteria?.[index] ?? 0;
                          const participantScore = participantCriterion.rating ?? 0;
                          const isDifferent = aiScore !== participantScore;

                          return participantCriterion ? (
                            <div key={participantCriterion.label} className="flex items-center justify-between text-sm">
                              <div className="flex items-center gap-2">
                                <span>{participantCriterion.label}:</span>
                                {isDifferent && <AlertCircleIcon className="h-4 w-4 text-orange-500" />}
                              </div>
                              <StarRow value={aiScore} />
                            </div>
                          ) : null;
                        })}
                      </div>
                    </div>
                  </div>
                )}
                {aiEvaluationError && (
                  <p className="text-sm text-red-500 mt-2">{aiEvaluationError}</p>
                )}
              </section>

              <Separator className="my-4" />

              {isReviewer ? (
                <>
                  {selected?.review ? (
                    <section className="space-y-2 rounded-lg border border-border/70 bg-muted/30 p-3">
                      <h3 className="text-sm font-semibold text-muted-foreground">Researcher decision</h3>
                      <div className="flex flex-wrap items-center gap-3 text-sm">
                        <span className="flex items-center gap-1">
                          <span className="text-muted-foreground">Status:</span>
                          {getStatusBadge(selected.review.status || "pending")}
                        </span>
                        <span className="flex items-center gap-1">
                          <span className="text-muted-foreground">Decision:</span>
                          {getDecisionBadge(selected.review.decision)}
                        </span>
                        {selected.review.adjudicatedLabel ? (
                          <span className="flex items-center gap-1">
                            <span className="text-muted-foreground">Label:</span>
                            <Badge variant="outline">{selected.review.adjudicatedLabel}</Badge>
                          </span>
                        ) : null}
                      </div>
                      {selected.review.notes ? (
                        <p className="text-sm text-muted-foreground">
                          {selected.review.notes}
                        </p>
                      ) : null}
                    </section>
                  ) : null}

                  <section className="space-y-4">
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <h3 className="text-sm font-semibold text-muted-foreground">Reviewer feedback</h3>
                        <p className="text-xs text-muted-foreground">
                          Share a quick rating and comment that the researcher will see.
                        </p>
                      </div>
                      {selected.review?.reviewerSubmittedAt ? (
                        <p className="text-xs text-muted-foreground">
                          Last saved {formatDateTime(selected.review.reviewerSubmittedAt)}
                        </p>
                      ) : null}
                    </div>
                    <ReviewerCommentsThread
                      comments={selected.review?.comments}
                      onDelete={handleDeleteNote}
                      canDelete={canDeleteNote}
                      deletingNoteId={deletingNoteId}
                    />
                    {hasSubmittedNote ? (
                      <div className="rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs text-emerald-800">
                        You already submitted feedback for this evaluation.
                      </div>
                    ) : null}
                    <div className="grid gap-3 md:grid-cols-2">
                      <div className="flex flex-col gap-2">
                        <label className="text-sm font-medium">Rating</label>
                        <Select
                          value={feedbackForm.rating}
                          onValueChange={(value) => handleFeedbackChange("rating", value)}
                          disabled={hasSubmittedNote}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="No rating" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">No rating</SelectItem>
                            {[1, 2, 3, 4, 5].map((value) => (
                              <SelectItem key={value} value={String(value)}>
                                {value} / 5
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <p className="text-xs text-muted-foreground">
                          Optional confidence/quality score (1–5).
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-sm font-medium">Reviewer comment</label>
                      <Textarea
                        value={feedbackForm.comment}
                        onChange={(event) => handleFeedbackChange("comment", event.target.value)}
                        rows={4}
                        disabled={hasSubmittedNote}
                        placeholder="What stood out? Mention agreement/disagreement with participant and why."
                      />
                    </div>
                  </section>
                </>
              ) : (
                <>
                  <section className="space-y-4">
                    <h3 className="text-sm font-semibold text-muted-foreground">Researcher decision</h3>
                    <div className="grid gap-3 md:grid-cols-2">
                      <div className="flex flex-col gap-2">
                        <label className="text-sm font-medium">Review status</label>
                        <Select
                          value={decisionForm.status}
                          onValueChange={(value) => handleDecisionChange("status", value)}
                          disabled={selected.review?.status === "resolved"}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Status" />
                          </SelectTrigger>
                          <SelectContent>
                            {STATUS_OPTIONS.filter((opt) => opt.value !== "all").map((opt) => (
                              <SelectItem key={opt.value} value={opt.value}>
                                {opt.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex flex-col gap-2">
                        <label className="text-sm font-medium">Decision</label>
                        <Select
                          value={decisionForm.decision}
                          onValueChange={(value) => handleDecisionChange("decision", value)}
                          disabled={selected.review?.status === "resolved"}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select decision" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="__none">No decision</SelectItem>
                            {DECISION_OPTIONS.map((option) => (
                              <SelectItem key={option.value} value={option.value}>
                                {option.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-sm font-medium">Adjudicated label</label>
                      <Input
                        value={decisionForm.adjudicatedLabel}
                        onChange={(event) => handleDecisionChange("adjudicatedLabel", event.target.value)}
                        disabled={selected.review?.status === "resolved"}
                        placeholder="e.g., GUI regression"
                      />
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-sm font-medium">Researcher notes</label>
                      <Textarea
                        value={decisionForm.notes}
                        onChange={(event) => handleDecisionChange("notes", event.target.value)}
                        rows={4}
                        disabled={selected.review?.status === "resolved"}
                        placeholder="Explain why you sided with the participant or LLM."
                      />
                    </div>
                    {formError && (
                      <p className="text-sm text-red-600">{formError}</p>
                    )}
                  </section>
                  <Separator className="my-4" />
                  <section className="space-y-2">
                    <h3 className="text-sm font-semibold text-muted-foreground">Reviewer comments</h3>
                    <ReviewerCommentsThread
                      comments={selected.review?.comments}
                      onDelete={handleDeleteNote}
                      canDelete={canDeleteNote}
                      deletingNoteId={deletingNoteId}
                    />
                  </section>
                </>
              )}

              <DialogFooter>
                <Button variant="ghost" onClick={closeDialog} disabled={savingDecision}>
                  Cancel
                </Button>
                {isReviewer ? null : (
                  <Button
                    onClick={handleSaveDecision}
                    disabled={savingDecision || noteSaving || selected.review?.status === "resolved"}
                  >
                    {savingDecision ? "Saving..." : "Save decision"}
                  </Button>
                )}
                {isReviewer ? (
                  <Button
                    onClick={handleSaveDecision}
                    disabled={savingDecision || noteSaving || hasSubmittedNote}
                  >
                    {hasSubmittedNote ? "Already submitted" : savingDecision ? "Saving..." : "Save feedback"}
                  </Button>
                ) : null}
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function StatusTile({ icon, label, value, tone }) {
  const IconComponent = icon;
  const toneClass = {
    amber: "bg-amber-50 text-amber-700 dark:bg-amber-900/30 dark:text-amber-100",
    blue: "bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-100",
    green: "bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-100",
  }[tone];

  return (
    <div className={`rounded-xl border p-4 flex items-center gap-3 ${toneClass}`}>
      <IconComponent className="h-6 w-6" />
      <div>
        <p className="text-sm font-medium">{label}</p>
        <p className="text-2xl font-semibold">{value}</p>
      </div>
    </div>
  );
}

function getStatusBadge(status) {
  const normalized = status || "pending";
  const map = {
    pending: { label: "Pending", variant: "outline" },
    in_review: { label: "In review", variant: "secondary" },
    resolved: { label: "Resolved", variant: "default" },
  };
  const meta = map[normalized] || map.pending;
  return <Badge variant={meta.variant}>{meta.label}</Badge>;
}

function getDecisionBadge(decision) {
  if (!decision) {
    return <Badge variant="outline">Awaiting decision</Badge>;
  }
  const label = DECISION_OPTIONS.find((option) => option.value === decision)?.label || decision;
  const toneClass = {
    participant_correct: "bg-emerald-500/15 text-emerald-600 border border-emerald-500/40 dark:bg-emerald-400/15 dark:text-emerald-200 dark:border-emerald-400/40",
    llm_correct: "bg-blue-500/15 text-blue-600 border border-blue-500/40 dark:bg-blue-400/15 dark:text-blue-200 dark:border-blue-400/40",
    inconclusive: "bg-amber-500/15 text-amber-700 border border-amber-500/40 dark:bg-amber-400/15 dark:text-amber-100 dark:border-amber-400/40",
    needs_followup: "bg-rose-500/15 text-rose-700 border border-rose-500/40 dark:bg-rose-400/15 dark:text-rose-100 dark:border-rose-400/40",
  }[decision] || "bg-primary/15 text-primary border border-primary/30 dark:bg-primary/20 dark:text-primary-foreground";
  return <Badge className={toneClass}>{label}</Badge>;
}

function ReviewerCommentsThread({ comments = [], onDelete, canDelete, deletingNoteId }) {
  if (!comments || comments.length === 0) {
    return (
      <div className="rounded-md border border-dashed p-3 text-xs text-muted-foreground">
        No reviewer feedback yet. Be the first to leave a rating and note.
      </div>
    );
  }
  return (
    <div className="space-y-3">
      {comments.map((note) => {
        const displayName = note.reviewer?.name || note.reviewer?.email || "Reviewer";
        const initial = displayName?.[0]?.toUpperCase() || "R";
        const deletable = typeof canDelete === "function" ? canDelete(note) : false;
        return (
          <div
            key={note.id}
            className="rounded-xl border border-border/70 bg-card p-3 shadow-sm"
          >
            <div className="flex items-start gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-sm font-semibold text-primary-foreground">
                {initial}
              </div>
              <div className="flex-1 space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="text-sm font-semibold">{displayName}</p>
                  {note.rating ? (
                    <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[11px] font-medium text-amber-800">
                      {note.rating}/5
                    </span>
                  ) : null}
                  <span className="text-[11px] text-muted-foreground">
                    {note.createdAt ? formatDateTime(note.createdAt) : "Just now"}
                  </span>
                </div>
                {note.comment ? (
                  <p className="text-sm leading-relaxed text-foreground">{note.comment}</p>
                ) : (
                  <p className="text-xs text-muted-foreground">No comment provided.</p>
                )}
              </div>
              {deletable && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-muted-foreground"
                  onClick={() => onDelete && onDelete(note.id)}
                  disabled={deletingNoteId === note.id}
                >
                  {deletingNoteId === note.id ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Trash2 className="h-4 w-4" />
                  )}
                  <span className="sr-only">Delete note</span>
                </Button>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function ReviewerNotePreview({ review }) {
  if (!review) {
    return <span className="text-xs text-muted-foreground">No reviewer note</span>;
  }
  const comments = Array.isArray(review.comments) ? review.comments : [];
  const first = comments[0] || null;
  const rating = first?.rating ?? review.rating;
  const comment = first?.comment ?? review.comment;
  if (!rating && !comment && !comments.length) {
    return <span className="text-xs text-muted-foreground">No reviewer note</span>;
  }
  return (
    <div className="space-y-1">
      {rating ? <p className="text-sm font-medium">{rating}/5</p> : null}
      {comment ? (
        <p className="text-xs text-muted-foreground max-w-[240px] truncate">{comment}</p>
      ) : null}
      {comments.length > 1 ? (
        <p className="text-[11px] text-muted-foreground">+{comments.length - 1} more</p>
      ) : null}
      {first?.createdAt ? (
        <p className="text-[11px] text-muted-foreground">
          {first?.reviewer?.name ? `${first.reviewer.name} · ` : ""}
          {formatDateTime(first.createdAt)}
        </p>
      ) : review.reviewerSubmittedAt ? (
        <p className="text-[11px] text-muted-foreground">
          Updated {formatDateTime(review.reviewerSubmittedAt)}
        </p>
      ) : null}
    </div>
  );
}

function formatDateTime(value) {
  if (!value) {
    return "—";
  }
  return new Date(value).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function getParticipantDisplayMeta(entry) {
  if (!entry) {
    return {
      isBlinded: false,
      name: "Participant",
      email: "",
      submittedLabel: formatDateTime(null),
    };
  }
  const isBlinded = Boolean(entry.study?.isBlinded);
  const name = entry.participant?.name || "Participant";
  const email = isBlinded ? BLINDED_PLACEHOLDER : entry.participant?.email || "";
  const submittedLabel = formatDateTime(entry.submittedAt);
  return { isBlinded, name, email, submittedLabel };
}

function ComparisonSummary({ comparison }) {
  if (!comparison) {
    return <p className="text-sm text-muted-foreground">No comparison metadata.</p>;
  }
  return (
    <div className="rounded-lg border p-4 space-y-3">
      <p className="text-sm font-medium text-muted-foreground">Prompt</p>
      <p className="text-sm">{comparison.prompt || "—"}</p>
      <div className="grid gap-4 md:grid-cols-2">
        <ArtifactCard title="Primary" artifact={comparison.primary} />
        <ArtifactCard title="Secondary" artifact={comparison.secondary} />
      </div>
    </div>
  );
}

function ArtifactCard({ title, artifact }) {
  if (!artifact) {
    return (
      <div className="rounded-lg border p-3">
        <p className="text-xs font-medium text-muted-foreground">{title}</p>
        <p className="text-sm">Not linked</p>
      </div>
    );
  }
  return (
    <div className="rounded-lg border p-3">
      <p className="text-xs font-medium text-muted-foreground">{title}</p>
      <p className="text-sm font-semibold">{artifact.artifactName || artifact.label}</p>
      <p className="text-xs text-muted-foreground capitalize">{artifact.artifactType || "—"}</p>
    </div>
  );
}

function AnswerSummary({ answer }) {
  if (!answer) {
    return <p className="text-sm text-muted-foreground">No submission data.</p>;
  }

  const payload = answer.payload || {};
  const mode = payload.mode || answer.mode || null;
  const normalizedMode = mode === "stage2" ? "stage1" : mode;
  const solidViolation = payload.solidViolation || payload.solid_violation;
  const solidComplexity = payload.solidComplexity || payload.solid_complexity;
  const solidFixedCode = payload.solidFixedCode || payload.solid_fixed_code;
  const solidComment = payload.assessmentComment || payload.assessment_comment;
  const paneHasContent = (pane) => {
    if (!pane) return false;
    if (pane.type === "text") return Boolean(pane.text && String(pane.text).trim());
    if (pane.type === "image" || pane.type === "pdf") return Boolean(pane.url);
    return false;
  };
  const leftData = paneHasContent(payload.left) ? payload.left : null;
  const rightData = paneHasContent(payload.right) ? payload.right : null;
  const snapshotDiff = payload.snapshotDiffData || payload.snapshot_diff_data || null;
  const customArtifacts = Array.isArray(payload.customArtifacts) ? payload.customArtifacts : [];
  const criteriaRatings = normalizeCriteriaRatings(payload);
  const criteriaSummary = summarizeCriteriaRatings(criteriaRatings);

  const qa = [];
  if (normalizedMode === "stage1") {
    qa.push({ q: "Bug category", a: payload.leftCategory || "—" });
    if (payload.assessmentComment) qa.push({ q: "Notes", a: payload.assessmentComment });
  } else if (normalizedMode === "solid") {
    qa.push({ q: "Violation", a: solidViolation || "—" });
    qa.push({ q: "Complexity", a: solidComplexity || "—" });
    qa.push({ q: "Refactor", a: solidFixedCode || "—" });
    if (solidComment) qa.push({ q: "Notes", a: solidComment });
  } else if (normalizedMode === "patch") {
    qa.push({ q: "Are patches clones?", a: payload.patchAreClones || "—" });
    if (payload.patchAreClones === "yes") {
      qa.push({ q: "Clone type", a: payload.patchCloneType || "—" });
    }
    if (payload.patchCloneComment) qa.push({ q: "Notes", a: payload.patchCloneComment });
  } else if (normalizedMode === "snapshot") {
    qa.push({ q: "Outcome", a: payload.snapshotOutcome || "—" });
    qa.push({
      q: "Change type",
      a:
        payload.snapshotChangeType === "other"
          ? payload.snapshotChangeTypeOther || "Other (unspecified)"
          : payload.snapshotChangeType || "—",
    });
    if (payload.assessmentComment) qa.push({ q: "Notes", a: payload.assessmentComment });
  } else if (normalizedMode === "custom") {
    const responses =
      payload.customResponses && typeof payload.customResponses === "object"
        ? payload.customResponses
        : {};
    const questions = Array.isArray(payload.customQuestions) ? payload.customQuestions : [];
    if (questions.length === 0) {
      qa.push({ q: "Custom questions", a: "No questions configured" });
    } else {
      questions.forEach((q, idx) => {
        qa.push({
          q: `Q${idx + 1}: ${q.prompt}`,
          a: responses[q.id] ?? "—",
        });
      });
    }
    if (payload.assessmentComment) qa.push({ q: "Notes", a: payload.assessmentComment });
  } else {
    if (payload.assessmentComment) qa.push({ q: "Notes", a: payload.assessmentComment });
  }

  return (
    <div className="space-y-3 rounded-lg border p-4">
      <div className="grid gap-4 md:grid-cols-2">
        <DetailField label="Preference" value={answer.preference || "—"} />
        <DetailField label="Rating" value={answer.rating ?? "—"} />
      </div>
      <DetailField label="Summary" value={answer.summary || "—"} />
      <DetailField label="Notes" value={answer.notes || "—"} />
      <DetailField label="Stage" value={getStageLabel(mode)} />
      {qa.length > 0 && (
        <div className="rounded-md border p-3 bg-muted/40 space-y-2">
          <p className="text-xs font-semibold text-muted-foreground">Participant responses</p>
          <div className="space-y-1">
            {qa.map((item, idx) => (
              <div key={`${item.q}-${idx}`} className="flex justify-between text-sm gap-2">
                <span className="text-muted-foreground">{item.q}</span>
                <span className="text-right font-medium">{item.a || "—"}</span>
              </div>
            ))}
          </div>
        </div>
      )}
      {criteriaRatings.length > 0 && (
        <div className="rounded-md border p-3 bg-muted/40 space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-xs font-semibold text-muted-foreground">Criteria ratings</p>
            {criteriaSummary.weighted !== null && (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-muted-foreground">Weighted score</span>
                <StarRow value={criteriaSummary.weighted} />
                <span className="text-muted-foreground">
                  {criteriaSummary.weighted.toFixed(2)} / 5
                  {criteriaSummary.weightTotal ? ` (weights total ${criteriaSummary.weightTotal}%)` : ""}
                </span>
              </div>
            )}
          </div>
          <div className="space-y-2">
            {criteriaRatings.map((item, idx) => (
              <div key={`${item.label}-${idx}`} className="flex items-center justify-between gap-3 text-sm">
                <div className="flex flex-col">
                  <span className="font-medium">{item.label}</span>
                  {item.weight != null && (
                    <span className="text-xs text-muted-foreground">Weight: {item.weight}%</span>
                  )}
                </div>
                <StarRow value={item.rating} />
              </div>
            ))}
          </div>
        </div>
      )}
      {solidViolation && (
        <div className="rounded-md border p-3 bg-muted/40 space-y-2">
          <p className="text-xs font-semibold text-muted-foreground">SOLID violation details</p>
          <DetailField label="Violation" value={solidViolation} />
          <DetailField label="Complexity" value={solidComplexity || "—"} />
          <DetailField label="Fixed code" value={solidFixedCode || "—"} />
          <DetailField label="Explanation" value={solidComment || "—"} />
        </div>
      )}

      {normalizedMode === "custom" && customArtifacts.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs font-semibold text-muted-foreground">
            Custom artifacts ({customArtifacts.length})
          </p>
          <div className="grid gap-3 md:grid-cols-2">
            {customArtifacts.map((pane, idx) => (
              <PanePreview
                key={pane.studyArtifactId || pane.artifactId || idx}
                title={`Artifact ${idx + 1}`}
                pane={pane}
              />
            ))}
          </div>
        </div>
      )}

      {normalizedMode !== "custom" && (leftData || rightData) && (
        <div
          className={`grid gap-3 ${leftData && rightData ? "md:grid-cols-2" : "grid-cols-1"}`}
        >
          {leftData && <PanePreview title="Artifact A" pane={leftData} />}
          {rightData && <PanePreview title="Artifact B" pane={rightData} />}
        </div>
      )}

      {snapshotDiff && (
        <div className="grid gap-3">
          <PanePreview title="Participant diff upload" pane={snapshotDiff} />
        </div>
      )}

      {answer.metrics && renderPayload(answer.metrics, "Metrics")}
    </div>
  );
}

function ArtifactSummaryCard({ title, artifact, summary, onGenerate }) {
  const name = artifact?.artifactName || artifact?.label || title;
  const type = artifact?.artifactType || "—";
  const hasId = Boolean(artifact?.artifactId);

  return (
    <div className="rounded-lg border p-3 space-y-2">
      <div className="flex items-center justify-between gap-2">
        <div>
          <p className="text-xs font-semibold text-muted-foreground">{title}</p>
          <p className="text-sm font-medium">{name}</p>
          <p className="text-xs text-muted-foreground capitalize">Type: {type}</p>
        </div>
        <Button variant="outline" size="sm" onClick={onGenerate} disabled={!hasId || summary.loading}>
          {summary.loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4 mr-1" />}
          {summary.loading ? "Summarizing..." : "AI summary"}
        </Button>
      </div>
      {summary.error && <p className="text-xs text-red-600">{summary.error}</p>}
      <p className="text-xs text-muted-foreground whitespace-pre-wrap">
        {summary.text || "No summary yet."}
      </p>
      {!hasId && <p className="text-[11px] text-amber-700">Artifact id missing; cannot summarize.</p>}
    </div>
  );
}

function PanePreview({ pane, title }) {
  if (!pane) {
    return (
      <div className="rounded-lg border p-3">
        <p className="text-xs font-semibold text-muted-foreground">{title}</p>
        <p className="text-sm text-muted-foreground">Not provided</p>
      </div>
    );
  }

  const kind = (pane.type || "").toLowerCase();
  const label = pane.name || title;

  if (kind === "image") {
    return (
      <div className="rounded-lg border p-3 space-y-2">
        <p className="text-xs font-semibold text-muted-foreground">{title}</p>
        <p className="text-sm font-medium">{label}</p>
        <img src={pane.url} alt={label} className="max-h-80 w-full object-contain border rounded" />
      </div>
    );
  }

  if (kind === "pdf") {
    return (
      <div className="rounded-lg border p-3 space-y-2">
        <p className="text-xs font-semibold text-muted-foreground">{title}</p>
        <p className="text-sm font-medium">{label}</p>
        <object data={pane.url} type="application/pdf" className="w-full h-80 border rounded">
          <a href={pane.url} target="_blank" rel="noreferrer" className="text-sm text-blue-600 underline">
            Open PDF
          </a>
        </object>
      </div>
    );
  }

  return (
    <div className="rounded-lg border p-3 space-y-2">
      <p className="text-xs font-semibold text-muted-foreground">{title}</p>
      <p className="text-sm font-medium">{label}</p>
      <pre className="whitespace-pre-wrap rounded bg-white p-2 text-xs border max-h-80 overflow-auto">
        {pane.text || "—"}
      </pre>
    </div>
  );
}

function GroundTruthSummary({ groundTruth }) {
  if (!groundTruth) {
    return <p className="text-sm text-muted-foreground">No ground truth metadata available.</p>;
  }
  return (
    <div className="space-y-3 rounded-lg border p-4">
      {renderPayload(groundTruth, "Ground truth details")}
    </div>
  );
}

function DetailField({ label, value }) {
  return (
    <div>
      <p className="text-xs font-semibold text-muted-foreground">{label}</p>
      <p className="text-sm">{String(value)}</p>
    </div>
  );
}

function renderPayload(payload, title) {
  if (!payload || typeof payload !== "object") {
    return null;
  }
  return (
    <div>
      <p className="text-xs font-semibold text-muted-foreground">{title}</p>
      <div className="mt-2 grid gap-2 rounded-md border p-3 text-sm bg-muted/30">
        {Object.entries(payload).map(([key, value]) => (
          <div key={key} className="flex items-start justify-between text-xs">
            <span className="font-medium capitalize text-muted-foreground">{key}</span>
            <span className="ml-4 text-right break-all">{formatValue(value)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function formatValue(value) {
  if (value === null || value === undefined) {
    return "—";
  }
  if (typeof value === "object") {
    return JSON.stringify(value);
  }
  return String(value);
}

function StarRow({ value }) {
  const rating = Number(value);
  const safe = Number.isFinite(rating) ? Math.max(0, Math.min(5, rating)) : 0;
  return (
    <div className="flex items-center gap-0.5 text-amber-500">
      {[1, 2, 3, 4, 5].map((star) => (
        <span key={star} className={star <= safe ? "text-amber-500" : "text-gray-300"}>
          ★
        </span>
      ))}
    </div>
  );
}

// helper removed (handled inline in component)
